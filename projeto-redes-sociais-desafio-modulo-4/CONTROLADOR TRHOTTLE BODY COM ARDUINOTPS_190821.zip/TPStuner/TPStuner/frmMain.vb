﻿
Public Class frmMain

    Private Sub frmLoad(sender As Object, e As EventArgs) Handles MyBase.Load
        'Attach the binding to the target 
        lblPosSpRaw.DataBindings.Add(New Binding("Text", genTPS, "posSpRaw", True, DataSourceUpdateMode.OnValidation, vbNull, "0 raw"))
        lblPosTpsARaw.DataBindings.Add(New Binding("Text", genTPS, "posTpsARaw", True, DataSourceUpdateMode.OnValidation, vbNull, "0 raw"))
        lblPosTpsBRaw.DataBindings.Add(New Binding("Text", genTPS, "posTpsBRaw", True, DataSourceUpdateMode.OnValidation, vbNull, "0 raw"))
        lblPosAmpRaw.DataBindings.Add(New Binding("Text", genTPS, "posAmpRaw", True, DataSourceUpdateMode.OnValidation, vbNull, "0 raw"))

        lblPosSpIn.DataBindings.Add(New Binding("Text", genTPS, "posSpIn", True, DataSourceUpdateMode.OnValidation, vbNull, "0 in"))
        lblPosSp.DataBindings.Add(New Binding("Text", genTPS, "posSp", True, DataSourceUpdateMode.OnValidation, vbNull, "0 out"))
        lblPosTps.DataBindings.Add(New Binding("Text", genTPS, "posTps", True, DataSourceUpdateMode.OnValidation, vbNull, "0 pos"))
        lblPosAmp.DataBindings.Add(New Binding("Text", genTPS, "posAmp", True, DataSourceUpdateMode.OnValidation, vbNull, "0 amp"))

        lblDemPwm.DataBindings.Add(New Binding("Text", genTPS, "demPwm", True, DataSourceUpdateMode.OnValidation, vbNull, "0 pwm"))
        lblErr.DataBindings.Add(New Binding("Text", genTPS, "err", True, DataSourceUpdateMode.OnValidation, vbNull, "0 err"))
        lblOutP.DataBindings.Add(New Binding("Text", genTPS, "outP", True, DataSourceUpdateMode.OnValidation, vbNull, "0-P"))
        lblOutI.DataBindings.Add(New Binding("Text", genTPS, "outI", True, DataSourceUpdateMode.OnValidation, vbNull, "0-I"))
        lblOutD.DataBindings.Add(New Binding("Text", genTPS, "outD", True, DataSourceUpdateMode.OnValidation, vbNull, "0-D"))
        lblOutFF.DataBindings.Add(New Binding("Text", genTPS, "outFF", True, DataSourceUpdateMode.OnValidation, vbNull, "0-FF"))

        lblTask.DataBindings.Add(New Binding("Text", genTPS, "task", True, DataSourceUpdateMode.OnValidation, vbNull, "0 us"))

        'länka comport objekt
        genComData.comPort = comPort


        'Trend configuration (static)
        genTrend.brd = 5
        genTrend.dpen = Pens.White
        genTrend.dpnlTrend = dpnlTrend

        genTrend.clrPen(0) = New Pen(My.Settings.clrTrendPen1)
        genTrend.clrPen(1) = New Pen(My.Settings.clrTrendPen2)
        genTrend.clrPen(2) = New Pen(My.Settings.clrTrendPen3)
        genTrend.clrPen(3) = New Pen(My.Settings.clrTrendPen4)
        genTrend.clrPen(4) = New Pen(My.Settings.clrTrendPen5)

        genTrend.bUsePen(0) = My.Settings.bUseTrendPen1
        genTrend.bUsePen(1) = My.Settings.bUseTrendPen2
        genTrend.bUsePen(2) = My.Settings.bUseTrendPen3
        genTrend.bUsePen(3) = My.Settings.bUseTrendPen4
        genTrend.bUsePen(4) = My.Settings.bUseTrendPen5

        genTrend.sTextPen(0) = My.Settings.sTextPen1
        genTrend.sTextPen(1) = My.Settings.sTextPen2
        genTrend.sTextPen(2) = My.Settings.sTextPen3
        genTrend.sTextPen(3) = My.Settings.sTextPen4
        genTrend.sTextPen(4) = My.Settings.sTextPen5

        Me.Size = My.Settings.frmMainSize
        splitMain.SplitterDistance = My.Settings.frmMainSplitDist1
        splitView.SplitterDistance = My.Settings.frmMainSplitDist2

        Dim assem As System.Reflection.Assembly = System.Reflection.Assembly.GetEntryAssembly()
        Dim assemName As System.Reflection.AssemblyName = assem.GetName()
        Dim ver As Version = assemName.Version

        Me.Text = Me.Text & " " & ver.ToString()

    End Sub

    Private Sub frmClosing(sender As Object, e As EventArgs) Handles MyBase.FormClosing

        My.Settings.frmMainSplitDist1 = splitMain.SplitterDistance
        My.Settings.frmMainSplitDist2 = splitView.SplitterDistance
        My.Settings.frmMainSize = Me.Size
        genComData.PortClose()

    End Sub

    Private Sub dpnlTrend_click(sender As Object, e As EventArgs) Handles dpnlTrend.Click
        If genComData.comPort.IsOpen Then
            If Not genComData.cmdStopSend Then
                genComData.cmdStopSend = True
            Else
                genComData.cmdStopSend = False
                genComData.cmdSend(tps.message.cmdComSend.txData)
            End If
        End If
    End Sub

    Private Sub dpnlTrend_MouseHover(sender As Object, e As MouseEventArgs) Handles dpnlTrend.MouseMove

        If genComData.cmdStopSend Then
            genTrend.Ypos = CInt((genTrend.rec.Height - e.Y) / genTrend.Ygain)
            dpnlInfo.Invalidate()
        Else
            genTrend.Ypos = -1
        End If

    End Sub

    Private Sub dpnlTrend_paint(ByVal sender As Object, e As PaintEventArgs) Handles dpnlTrend.Paint

        With dpnlTrend
            Dim centre As Point = New Point(.ClientSize.Width \ 2, .ClientSize.Height \ 2)
            genTrend.rec = New Rectangle(genTrend.brd, genTrend.brd, .ClientSize.Width - genTrend.brd * 2, .ClientSize.Height - genTrend.brd * 2)
            genTrend.lgBrush = New System.Drawing.Drawing2D.LinearGradientBrush(genTrend.rec, Color.FromArgb(255, 255, 255), Color.FromArgb(245, 245, 245), 60)

            'bakgrund o kant
            e.Graphics.FillRectangle(genTrend.lgBrush, genTrend.rec)
            e.Graphics.DrawRectangle(genTrend.dpen, genTrend.rec)
            e.Graphics.DrawLine(Pens.Green, genTrend.rec.Left, centre.Y, genTrend.rec.Left + genTrend.rec.Width, centre.Y)
            genTrend.Xpos = genTrend.rec.Left
            genTrend.Ygain = (genTrend.rec.Height - 2) / 1024.0F
            TrendWrite(0, 0, False, True)
        End With
    End Sub
    Private Sub dpnlGauge_paint(ByVal sender As Object, e As PaintEventArgs) Handles dpnlGauge.Paint

        With dpnlGauge
            Dim centre As Point = New Point(.ClientSize.Width \ 2, .ClientSize.Height \ 2)
            Dim dia As Int32 = If(.ClientSize.Width < .ClientSize.Height - 30, .ClientSize.Width - 8, .ClientSize.Height - 30)
            Dim rec As Rectangle = New Rectangle(centre.X - dia \ 2, centre.Y - dia \ 2, dia, dia)
            Dim lgBrush As New System.Drawing.Drawing2D.LinearGradientBrush(rec, Color.DarkGray, Color.Black, 60)
            Dim dpen As System.Drawing.Pen = Pens.DarkGray

            'bakgrund o kant
            e.Graphics.FillEllipse(Brushes.WhiteSmoke, rec)
            e.Graphics.DrawEllipse(dpen, rec)

            Dim aPen As New Pen(Color.Blue, 2)
            Dim stAng As Single = 180.0F
            Dim swAng As Single = 90.0F
            e.Graphics.DrawArc(aPen, rec, stAng, swAng)
            stAng = 0 : swAng = 90
            e.Graphics.DrawArc(aPen, rec, stAng, swAng)

            Dim xpT As Int32
            Dim ypT As Int32
            Dim xpS As Int32
            Dim ypS As Int32
            Dim r As Int32 = CInt(rec.Width / 2)
            Dim aTps As Double = genTPS.posTps / 1024 * 90 * Math.PI / 180
            Dim aSp As Double = genTPS.posSp / 1024 * 90 * Math.PI / 180

            Dim tpsPen As New Pen(Color.Black, 5)
            Dim spPen As New Pen(Color.Red, 1)

            xpT = CInt(r * Math.Cos(aTps))
            ypT = CInt(r * Math.Sin(aTps))
            xpS = CInt(r * Math.Cos(aSp))
            ypS = CInt(r * Math.Sin(aSp))

            Dim s As String = "Angle=" & FormatNumber(aTps / Math.PI * 180, 1)

            e.Graphics.DrawString(s, New Font("Arial", 8), Brushes.ForestGreen, New System.Drawing.Point(3, 3))

            e.Graphics.DrawLine(tpsPen, centre.X - xpT, centre.Y - ypT, centre.X + xpT, centre.Y + ypT)
            e.Graphics.DrawLine(spPen, centre.X - xpS, centre.Y - ypS, centre.X + xpS, centre.Y + ypS)

            Dim stAngE As Single = 180.0F + CSng(Math.Min(aTps, aSp) / Math.PI * 180)
            Dim swAngE As Single = CSng((Math.Max(aTps, aSp) - Math.Min(aTps, aSp)) / Math.PI * 180)
            e.Graphics.FillPie(Brushes.Red, rec, stAngE, swAngE)

            stAngE -= 180.0F
            e.Graphics.FillPie(Brushes.Red, rec, stAngE, swAngE)

            'center
            Dim cdia As Int32 = 16
            Dim crec As Rectangle = New Rectangle(centre.X - cdia \ 2, centre.Y - cdia \ 2, cdia, cdia)
            e.Graphics.FillEllipse(Brushes.Blue, crec)

        End With

    End Sub
    Private Sub dpnlInfo_paint(ByVal sender As Object, e As PaintEventArgs) Handles dpnlInfo.Paint


        'e.Graphics.DrawString("Pointer 0ms", New Font("Arial", 8), Brushes.ForestGreen, New System.Drawing.Point(3, 3))
        If genComData.cmdStopSend Then
            e.Graphics.DrawString("Value " & genTrend.Ypos, New Font("Arial", 8), Brushes.ForestGreen, New System.Drawing.Point(3, 3))
        End If

        Dim y As Integer = 15
        For x = 0 To UBound(genTrend.clrPen)
            If genTrend.bUsePen(x) Then
                e.Graphics.DrawString(genTrend.sTextPen(x), New Font("Arial", 8), New SolidBrush(genTrend.clrPen(x).Color), New System.Drawing.Point(3, y))
                y += 12
            End If
        Next


    End Sub
    Private Sub tsbClose_Click(sender As Object, e As EventArgs) Handles tsbClose.Click
        genComData.PortClose()
    End Sub

    Private Async Sub tsbOpen_Click(sender As Object, e As EventArgs) Handles tsbOpen.Click
        genComData.PortOPen()
        Await ParametersRead()
    End Sub

    Private Sub tsbSettings_Click(sender As Object, e As EventArgs) Handles tsbSettings.Click
        frmSettings.Show()
    End Sub

    Private Sub UpdateValues(bTrend As Boolean)
        Static oTicks As Long
        Static oClk As Int16
        Dim x As Integer
        Dim eTicks As Long = DateTime.Now.Ticks - oTicks
        oTicks = DateTime.Now.Ticks
        oClk = genTPS.clk

        If Not bTrend Then
            genTPS.posSpRaw = BitConverter.ToInt16(genComData.input, 0)
            genTPS.posTpsARaw = BitConverter.ToInt16(genComData.input, 2)
            genTPS.posTpsBRaw = BitConverter.ToInt16(genComData.input, 4)
            genTPS.posAmpRaw = BitConverter.ToInt16(genComData.input, 6)
            genTPS.posSpIn = BitConverter.ToInt16(genComData.input, 8)
            genTPS.posSp = BitConverter.ToInt16(genComData.input, 10)
            genTPS.posTps = BitConverter.ToInt16(genComData.input, 12)
            genTPS.posAmp = BitConverter.ToInt16(genComData.input, 14)
            genTPS.demPwm = BitConverter.ToInt16(genComData.input, 16)
            genTPS.err = BitConverter.ToInt16(genComData.input, 18)
            genTPS.outP = BitConverter.ToInt16(genComData.input, 20)
            genTPS.outI = BitConverter.ToInt16(genComData.input, 22)
            genTPS.outD = BitConverter.ToInt16(genComData.input, 24)
            genTPS.outFF = BitConverter.ToInt16(genComData.input, 26)
            genTPS.task = BitConverter.ToInt32(genComData.input, 28)
            genTPS.clk = genComData.input(32)


            TrendWrite(genTPS.posSp, 0, True, , True)
            TrendWrite(genTPS.posTps, 1)
            TrendWrite(genTPS.demPwm + 512S - 135S, 2)
            TrendWrite(genTPS.err + 512S, 3)
            genTrend.Xpos += 3

        Else

            For x = 0 To UBound(genComData.input) - 1 Step 8
                genTPS.posTps = BitConverter.ToInt16(genComData.input, x)
                genTPS.posSp = BitConverter.ToInt16(genComData.input, x + 2)
                genTPS.demPwm = BitConverter.ToInt16(genComData.input, x + 4)
                Dim sVal As Short = BitConverter.ToInt16(genComData.input, x + 6)
                If (genTPS.bitPrm And &H2) > 0 Then genTPS.outP = sVal
                If (genTPS.bitPrm And &H4) > 0 Then genTPS.outI = sVal
                If (genTPS.bitPrm And &H8) > 0 Then genTPS.outD = sVal
                If (genTPS.bitPrm And &H10) > 0 Then genTPS.outFF = sVal
                If (genTPS.bitPrm And &H20) > 0 Then genTPS.posAmp = sVal

                genTPS.err = genTPS.posSp - genTPS.posTps

                TrendWrite(genTPS.posSp, 0, True)
                TrendWrite(genTPS.posTps, 1)
                TrendWrite(genTPS.demPwm + 512S - genTPS.pwmOfs, 2)
                TrendWrite(genTPS.err + 512S, 3)
                TrendWrite(sVal + 512S, 4)
                genTrend.Xpos += 3

                If genTrend.Xpos > genTrend.rec.Width + genTrend.rec.Left Then dpnlTrend.Invalidate()

            Next x
        End If
        'If genTPS.clk <> oClk Then dpnlTrend.Invalidate()

        dpnlGauge.Invalidate()
        genComData.newValues = False
        If Not genComData.cmdStopSend Then
            genComData.cmdSend(tps.message.cmdComSend.txData)
        End If
        sslLoop.Text = " Looptime " & FormatNumber(eTicks / 10000, 2) & "ms, buffert sync " & genTPS.clk & ", sync diff " & genTPS.clk - oClk

    End Sub

    Private Sub TrendWrite(value As Short, idx As Integer, Optional cLine As Boolean = False, Optional oRst As Boolean = False, Optional bMark As Boolean = False)
        Static oX(4) As Int32
        Static oY(4) As Int32

        If oRst Then
            Dim x As Int32
            For x = 0 To UBound(genTrend.clrPen)
                oX(x) = genTrend.Xpos
            Next x
            Exit Sub
        End If

        With genTrend.dpnlTrend
            Dim g As Graphics = .CreateGraphics
            If cLine Then
                g.DrawLine(genTrend.dpen, genTrend.Xpos, genTrend.rec.Top, genTrend.Xpos, genTrend.rec.Top + genTrend.rec.Height)
            End If
            If bMark Then
                g.DrawLine(Pens.LightGray, genTrend.Xpos, genTrend.rec.Top, genTrend.Xpos, genTrend.rec.Top + genTrend.rec.Height)
            End If

            Dim y As Int32 = genTrend.rec.Height - CInt(value * genTrend.Ygain)


            If genTrend.bUsePen(idx) Then g.DrawLine(genTrend.clrPen(idx), genTrend.Xpos, y, oX(idx), oY(idx))

            oX(idx) = genTrend.Xpos
            oY(idx) = y
        End With
    End Sub
    Private Sub Timer_Tick(sender As Object, e As EventArgs) Handles Timer.Tick
        If genComData.newValues Then UpdateValues(genComData.newTrend)
    End Sub


End Class




