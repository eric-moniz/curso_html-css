﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSettings
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.flpSettings = New System.Windows.Forms.FlowLayoutPanel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.cmbCom = New System.Windows.Forms.ComboBox()
        Me.lblCom = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.nudPTsk = New System.Windows.Forms.NumericUpDown()
        Me.nudSSnd = New System.Windows.Forms.NumericUpDown()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.nudKpInvNeg = New System.Windows.Forms.NumericUpDown()
        Me.nudKpInv = New System.Windows.Forms.NumericUpDown()
        Me.lblP = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.nudIWinMax = New System.Windows.Forms.NumericUpDown()
        Me.nudIWin = New System.Windows.Forms.NumericUpDown()
        Me.nudIMax = New System.Windows.Forms.NumericUpDown()
        Me.nudKiInv = New System.Windows.Forms.NumericUpDown()
        Me.Panel20 = New System.Windows.Forms.Panel()
        Me.lblI = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.nudKpDNeg = New System.Windows.Forms.NumericUpDown()
        Me.nudKpD = New System.Windows.Forms.NumericUpDown()
        Me.lblD = New System.Windows.Forms.Label()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.nudKpFFNeg = New System.Windows.Forms.NumericUpDown()
        Me.nudKpFF = New System.Windows.Forms.NumericUpDown()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.nudPwmOfs = New System.Windows.Forms.NumericUpDown()
        Me.lblOfs = New System.Windows.Forms.Label()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.nudSpMax = New System.Windows.Forms.NumericUpDown()
        Me.nudSpMin = New System.Windows.Forms.NumericUpDown()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.nudTpsMax = New System.Windows.Forms.NumericUpDown()
        Me.nudTpsMin = New System.Windows.Forms.NumericUpDown()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel19 = New System.Windows.Forms.Panel()
        Me.cbBitPrm0 = New System.Windows.Forms.CheckBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.pnlTable = New System.Windows.Forms.Panel()
        Me.nudTblPos15 = New System.Windows.Forms.NumericUpDown()
        Me.nudTblSp15 = New System.Windows.Forms.NumericUpDown()
        Me.nudTblPos7 = New System.Windows.Forms.NumericUpDown()
        Me.nudTblSp7 = New System.Windows.Forms.NumericUpDown()
        Me.nudTblPos14 = New System.Windows.Forms.NumericUpDown()
        Me.nudTblSp14 = New System.Windows.Forms.NumericUpDown()
        Me.nudTblPos6 = New System.Windows.Forms.NumericUpDown()
        Me.nudTblSp6 = New System.Windows.Forms.NumericUpDown()
        Me.nudTblPos13 = New System.Windows.Forms.NumericUpDown()
        Me.nudTblSp13 = New System.Windows.Forms.NumericUpDown()
        Me.nudTblPos5 = New System.Windows.Forms.NumericUpDown()
        Me.nudTblSp5 = New System.Windows.Forms.NumericUpDown()
        Me.nudTblPos12 = New System.Windows.Forms.NumericUpDown()
        Me.nudTblSp12 = New System.Windows.Forms.NumericUpDown()
        Me.nudTblPos4 = New System.Windows.Forms.NumericUpDown()
        Me.nudTblSp4 = New System.Windows.Forms.NumericUpDown()
        Me.nudTblPos11 = New System.Windows.Forms.NumericUpDown()
        Me.nudTblSp11 = New System.Windows.Forms.NumericUpDown()
        Me.nudTblPos3 = New System.Windows.Forms.NumericUpDown()
        Me.nudTblSp3 = New System.Windows.Forms.NumericUpDown()
        Me.nudTblPos10 = New System.Windows.Forms.NumericUpDown()
        Me.nudTblSp10 = New System.Windows.Forms.NumericUpDown()
        Me.nudTblPos2 = New System.Windows.Forms.NumericUpDown()
        Me.nudTblSp2 = New System.Windows.Forms.NumericUpDown()
        Me.nudTblPos9 = New System.Windows.Forms.NumericUpDown()
        Me.nudTblSp9 = New System.Windows.Forms.NumericUpDown()
        Me.nudTblPos1 = New System.Windows.Forms.NumericUpDown()
        Me.nudTblSp1 = New System.Windows.Forms.NumericUpDown()
        Me.nudTblPos8 = New System.Windows.Forms.NumericUpDown()
        Me.nudTblSp8 = New System.Windows.Forms.NumericUpDown()
        Me.nudTblPos0 = New System.Windows.Forms.NumericUpDown()
        Me.nudTblSp0 = New System.Windows.Forms.NumericUpDown()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.Panel21 = New System.Windows.Forms.Panel()
        Me.rbFF = New System.Windows.Forms.RadioButton()
        Me.rbAmp = New System.Windows.Forms.RadioButton()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.rbP = New System.Windows.Forms.RadioButton()
        Me.rbD = New System.Windows.Forms.RadioButton()
        Me.rbI = New System.Windows.Forms.RadioButton()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.pnlClrPen1 = New System.Windows.Forms.Panel()
        Me.cbUsePen1 = New System.Windows.Forms.CheckBox()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.pnlClrPen2 = New System.Windows.Forms.Panel()
        Me.cbUsePen2 = New System.Windows.Forms.CheckBox()
        Me.Panel14 = New System.Windows.Forms.Panel()
        Me.pnlClrPen3 = New System.Windows.Forms.Panel()
        Me.cbUsePen3 = New System.Windows.Forms.CheckBox()
        Me.Panel16 = New System.Windows.Forms.Panel()
        Me.pnlClrPen4 = New System.Windows.Forms.Panel()
        Me.cbUsePen4 = New System.Windows.Forms.CheckBox()
        Me.Panel18 = New System.Windows.Forms.Panel()
        Me.pnlClrPen5 = New System.Windows.Forms.Panel()
        Me.cbUsePen5 = New System.Windows.Forms.CheckBox()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.btnUpload = New System.Windows.Forms.Button()
        Me.btnDownload = New System.Windows.Forms.Button()
        Me.clrDialog = New System.Windows.Forms.ColorDialog()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.cbBitPrm1 = New System.Windows.Forms.CheckBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.nudDCerr = New System.Windows.Forms.NumericUpDown()
        Me.nudTpsAB = New System.Windows.Forms.NumericUpDown()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.flpSettings.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        CType(Me.nudPTsk, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudSSnd, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        CType(Me.nudKpInvNeg, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudKpInv, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel5.SuspendLayout()
        CType(Me.nudIWinMax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudIWin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudIMax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudKiInv, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel20.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.nudKpDNeg, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudKpD, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel9.SuspendLayout()
        CType(Me.nudKpFFNeg, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudKpFF, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel6.SuspendLayout()
        CType(Me.nudPwmOfs, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel7.SuspendLayout()
        CType(Me.nudSpMax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudSpMin, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel8.SuspendLayout()
        CType(Me.nudTpsMax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTpsMin, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel19.SuspendLayout()
        Me.pnlTable.SuspendLayout()
        CType(Me.nudTblPos15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTblSp15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTblPos7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTblSp7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTblPos14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTblSp14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTblPos6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTblSp6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTblPos13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTblSp13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTblPos5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTblSp5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTblPos12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTblSp12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTblPos4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTblSp4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTblPos11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTblSp11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTblPos3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTblSp3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTblPos10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTblSp10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTblPos2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTblSp2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTblPos9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTblSp9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTblPos1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTblSp1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTblPos8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTblSp8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTblPos0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTblSp0, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel11.SuspendLayout()
        Me.Panel21.SuspendLayout()
        Me.Panel12.SuspendLayout()
        Me.Panel10.SuspendLayout()
        Me.Panel14.SuspendLayout()
        Me.Panel16.SuspendLayout()
        Me.Panel18.SuspendLayout()
        Me.Panel13.SuspendLayout()
        CType(Me.nudDCerr, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTpsAB, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'flpSettings
        '
        Me.flpSettings.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.flpSettings.Controls.Add(Me.Panel2)
        Me.flpSettings.Controls.Add(Me.Panel3)
        Me.flpSettings.Controls.Add(Me.Panel4)
        Me.flpSettings.Controls.Add(Me.Panel5)
        Me.flpSettings.Controls.Add(Me.Panel1)
        Me.flpSettings.Controls.Add(Me.Panel9)
        Me.flpSettings.Controls.Add(Me.Panel6)
        Me.flpSettings.Controls.Add(Me.Panel7)
        Me.flpSettings.Controls.Add(Me.Panel8)
        Me.flpSettings.Controls.Add(Me.Panel13)
        Me.flpSettings.Controls.Add(Me.Panel19)
        Me.flpSettings.Controls.Add(Me.pnlTable)
        Me.flpSettings.Controls.Add(Me.Panel11)
        Me.flpSettings.Controls.Add(Me.Panel12)
        Me.flpSettings.Controls.Add(Me.Panel10)
        Me.flpSettings.Controls.Add(Me.Panel14)
        Me.flpSettings.Controls.Add(Me.Panel16)
        Me.flpSettings.Controls.Add(Me.Panel18)
        Me.flpSettings.FlowDirection = System.Windows.Forms.FlowDirection.TopDown
        Me.flpSettings.Location = New System.Drawing.Point(1, 1)
        Me.flpSettings.Name = "flpSettings"
        Me.flpSettings.Size = New System.Drawing.Size(727, 300)
        Me.flpSettings.TabIndex = 1
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.cmbCom)
        Me.Panel2.Controls.Add(Me.lblCom)
        Me.Panel2.Location = New System.Drawing.Point(3, 3)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(223, 25)
        Me.Panel2.TabIndex = 2
        '
        'cmbCom
        '
        Me.cmbCom.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.TPStuner.My.MySettings.Default, "sComPort", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.cmbCom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbCom.FormattingEnabled = True
        Me.cmbCom.Location = New System.Drawing.Point(117, 2)
        Me.cmbCom.Name = "cmbCom"
        Me.cmbCom.Size = New System.Drawing.Size(65, 21)
        Me.cmbCom.TabIndex = 3
        Me.cmbCom.Text = Global.TPStuner.My.MySettings.Default.sComPort
        '
        'lblCom
        '
        Me.lblCom.Location = New System.Drawing.Point(3, 3)
        Me.lblCom.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblCom.Name = "lblCom"
        Me.lblCom.Size = New System.Drawing.Size(99, 18)
        Me.lblCom.TabIndex = 27
        Me.lblCom.Text = "COM port"
        Me.lblCom.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.nudPTsk)
        Me.Panel3.Controls.Add(Me.nudSSnd)
        Me.Panel3.Controls.Add(Me.Label4)
        Me.Panel3.Location = New System.Drawing.Point(3, 34)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(260, 24)
        Me.Panel3.TabIndex = 3
        '
        'nudPTsk
        '
        Me.nudPTsk.BackColor = System.Drawing.Color.Black
        Me.nudPTsk.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudPTsk.Location = New System.Drawing.Point(188, 3)
        Me.nudPTsk.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudPTsk.Maximum = New Decimal(New Integer() {30000, 0, 0, 0})
        Me.nudPTsk.Name = "nudPTsk"
        Me.nudPTsk.Size = New System.Drawing.Size(65, 20)
        Me.nudPTsk.TabIndex = 5
        Me.nudPTsk.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudPTsk.Value = New Decimal(New Integer() {10024, 0, 0, 0})
        '
        'nudSSnd
        '
        Me.nudSSnd.BackColor = System.Drawing.Color.Black
        Me.nudSSnd.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudSSnd.Location = New System.Drawing.Point(117, 3)
        Me.nudSSnd.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudSSnd.Maximum = New Decimal(New Integer() {30000, 0, 0, 0})
        Me.nudSSnd.Name = "nudSSnd"
        Me.nudSSnd.Size = New System.Drawing.Size(65, 20)
        Me.nudSSnd.TabIndex = 4
        Me.nudSSnd.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudSSnd.Value = New Decimal(New Integer() {10024, 0, 0, 0})
        '
        'Label4
        '
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label4.Location = New System.Drawing.Point(3, 3)
        Me.Label4.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(117, 20)
        Me.Label4.TabIndex = 27
        Me.Label4.Text = "Trend/PID task us"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.nudKpInvNeg)
        Me.Panel4.Controls.Add(Me.nudKpInv)
        Me.Panel4.Controls.Add(Me.lblP)
        Me.Panel4.Location = New System.Drawing.Point(3, 64)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(223, 24)
        Me.Panel4.TabIndex = 4
        '
        'nudKpInvNeg
        '
        Me.nudKpInvNeg.BackColor = System.Drawing.Color.Black
        Me.nudKpInvNeg.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudKpInvNeg.Location = New System.Drawing.Point(170, 3)
        Me.nudKpInvNeg.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudKpInvNeg.Maximum = New Decimal(New Integer() {1024, 0, 0, 0})
        Me.nudKpInvNeg.Name = "nudKpInvNeg"
        Me.nudKpInvNeg.Size = New System.Drawing.Size(48, 20)
        Me.nudKpInvNeg.TabIndex = 7
        Me.nudKpInvNeg.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudKpInvNeg.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudKpInv
        '
        Me.nudKpInv.BackColor = System.Drawing.Color.Black
        Me.nudKpInv.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudKpInv.Location = New System.Drawing.Point(117, 3)
        Me.nudKpInv.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudKpInv.Maximum = New Decimal(New Integer() {1024, 0, 0, 0})
        Me.nudKpInv.Name = "nudKpInv"
        Me.nudKpInv.Size = New System.Drawing.Size(48, 20)
        Me.nudKpInv.TabIndex = 6
        Me.nudKpInv.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudKpInv.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'lblP
        '
        Me.lblP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblP.Location = New System.Drawing.Point(3, 3)
        Me.lblP.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblP.Name = "lblP"
        Me.lblP.Size = New System.Drawing.Size(117, 20)
        Me.lblP.TabIndex = 18
        Me.lblP.Text = "P gain pos/neg"
        Me.lblP.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.nudIWinMax)
        Me.Panel5.Controls.Add(Me.nudIWin)
        Me.Panel5.Controls.Add(Me.nudIMax)
        Me.Panel5.Controls.Add(Me.nudKiInv)
        Me.Panel5.Controls.Add(Me.Panel20)
        Me.Panel5.Location = New System.Drawing.Point(3, 94)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(223, 48)
        Me.Panel5.TabIndex = 5
        '
        'nudIWinMax
        '
        Me.nudIWinMax.BackColor = System.Drawing.Color.Black
        Me.nudIWinMax.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudIWinMax.Location = New System.Drawing.Point(170, 26)
        Me.nudIWinMax.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudIWinMax.Maximum = New Decimal(New Integer() {1024, 0, 0, 0})
        Me.nudIWinMax.Name = "nudIWinMax"
        Me.nudIWinMax.Size = New System.Drawing.Size(48, 20)
        Me.nudIWinMax.TabIndex = 11
        Me.nudIWinMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudIWinMax.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudIWin
        '
        Me.nudIWin.BackColor = System.Drawing.Color.Black
        Me.nudIWin.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudIWin.Location = New System.Drawing.Point(117, 26)
        Me.nudIWin.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudIWin.Maximum = New Decimal(New Integer() {1024, 0, 0, 0})
        Me.nudIWin.Name = "nudIWin"
        Me.nudIWin.Size = New System.Drawing.Size(48, 20)
        Me.nudIWin.TabIndex = 10
        Me.nudIWin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudIWin.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudIMax
        '
        Me.nudIMax.BackColor = System.Drawing.Color.Black
        Me.nudIMax.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudIMax.Location = New System.Drawing.Point(171, 3)
        Me.nudIMax.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudIMax.Maximum = New Decimal(New Integer() {9999, 0, 0, 0})
        Me.nudIMax.Name = "nudIMax"
        Me.nudIMax.Size = New System.Drawing.Size(48, 20)
        Me.nudIMax.TabIndex = 9
        Me.nudIMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudIMax.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudKiInv
        '
        Me.nudKiInv.BackColor = System.Drawing.Color.Black
        Me.nudKiInv.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudKiInv.Location = New System.Drawing.Point(117, 3)
        Me.nudKiInv.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudKiInv.Maximum = New Decimal(New Integer() {1024, 0, 0, 0})
        Me.nudKiInv.Name = "nudKiInv"
        Me.nudKiInv.Size = New System.Drawing.Size(48, 20)
        Me.nudKiInv.TabIndex = 8
        Me.nudKiInv.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudKiInv.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'Panel20
        '
        Me.Panel20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel20.Controls.Add(Me.lblI)
        Me.Panel20.Controls.Add(Me.Label7)
        Me.Panel20.Location = New System.Drawing.Point(3, 3)
        Me.Panel20.Name = "Panel20"
        Me.Panel20.Size = New System.Drawing.Size(115, 44)
        Me.Panel20.TabIndex = 34
        '
        'lblI
        '
        Me.lblI.Location = New System.Drawing.Point(1, -1)
        Me.lblI.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblI.Name = "lblI"
        Me.lblI.Size = New System.Drawing.Size(95, 20)
        Me.lblI.TabIndex = 23
        Me.lblI.Text = "I gain/max"
        Me.lblI.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(1, 22)
        Me.Label7.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(95, 20)
        Me.Label7.TabIndex = 32
        Me.Label7.Text = "I window min/max"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.nudKpDNeg)
        Me.Panel1.Controls.Add(Me.nudKpD)
        Me.Panel1.Controls.Add(Me.lblD)
        Me.Panel1.Location = New System.Drawing.Point(3, 148)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(223, 24)
        Me.Panel1.TabIndex = 6
        '
        'nudKpDNeg
        '
        Me.nudKpDNeg.BackColor = System.Drawing.Color.Black
        Me.nudKpDNeg.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudKpDNeg.Location = New System.Drawing.Point(171, 3)
        Me.nudKpDNeg.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudKpDNeg.Maximum = New Decimal(New Integer() {1024, 0, 0, 0})
        Me.nudKpDNeg.Name = "nudKpDNeg"
        Me.nudKpDNeg.Size = New System.Drawing.Size(48, 20)
        Me.nudKpDNeg.TabIndex = 13
        Me.nudKpDNeg.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudKpDNeg.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudKpD
        '
        Me.nudKpD.BackColor = System.Drawing.Color.Black
        Me.nudKpD.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudKpD.Location = New System.Drawing.Point(117, 3)
        Me.nudKpD.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudKpD.Maximum = New Decimal(New Integer() {1024, 0, 0, 0})
        Me.nudKpD.Name = "nudKpD"
        Me.nudKpD.Size = New System.Drawing.Size(48, 20)
        Me.nudKpD.TabIndex = 12
        Me.nudKpD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudKpD.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'lblD
        '
        Me.lblD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblD.Location = New System.Drawing.Point(3, 3)
        Me.lblD.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblD.Name = "lblD"
        Me.lblD.Size = New System.Drawing.Size(117, 20)
        Me.lblD.TabIndex = 23
        Me.lblD.Text = "D gain pos/neg"
        Me.lblD.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel9
        '
        Me.Panel9.Controls.Add(Me.nudKpFFNeg)
        Me.Panel9.Controls.Add(Me.nudKpFF)
        Me.Panel9.Controls.Add(Me.Label3)
        Me.Panel9.Location = New System.Drawing.Point(3, 178)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(223, 24)
        Me.Panel9.TabIndex = 7
        '
        'nudKpFFNeg
        '
        Me.nudKpFFNeg.BackColor = System.Drawing.Color.Black
        Me.nudKpFFNeg.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudKpFFNeg.Location = New System.Drawing.Point(171, 3)
        Me.nudKpFFNeg.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudKpFFNeg.Maximum = New Decimal(New Integer() {1024, 0, 0, 0})
        Me.nudKpFFNeg.Name = "nudKpFFNeg"
        Me.nudKpFFNeg.Size = New System.Drawing.Size(48, 20)
        Me.nudKpFFNeg.TabIndex = 16
        Me.nudKpFFNeg.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudKpFFNeg.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudKpFF
        '
        Me.nudKpFF.BackColor = System.Drawing.Color.Black
        Me.nudKpFF.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudKpFF.Location = New System.Drawing.Point(117, 3)
        Me.nudKpFF.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudKpFF.Maximum = New Decimal(New Integer() {1024, 0, 0, 0})
        Me.nudKpFF.Name = "nudKpFF"
        Me.nudKpFF.Size = New System.Drawing.Size(48, 20)
        Me.nudKpFF.TabIndex = 15
        Me.nudKpFF.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudKpFF.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'Label3
        '
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label3.Location = New System.Drawing.Point(3, 3)
        Me.Label3.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(117, 20)
        Me.Label3.TabIndex = 23
        Me.Label3.Text = "FF gain pos/neg"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.nudPwmOfs)
        Me.Panel6.Controls.Add(Me.lblOfs)
        Me.Panel6.Location = New System.Drawing.Point(3, 208)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(223, 24)
        Me.Panel6.TabIndex = 8
        '
        'nudPwmOfs
        '
        Me.nudPwmOfs.BackColor = System.Drawing.Color.Black
        Me.nudPwmOfs.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudPwmOfs.Location = New System.Drawing.Point(117, 3)
        Me.nudPwmOfs.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudPwmOfs.Maximum = New Decimal(New Integer() {255, 0, 0, 0})
        Me.nudPwmOfs.Name = "nudPwmOfs"
        Me.nudPwmOfs.Size = New System.Drawing.Size(48, 20)
        Me.nudPwmOfs.TabIndex = 18
        Me.nudPwmOfs.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudPwmOfs.Value = New Decimal(New Integer() {255, 0, 0, 0})
        '
        'lblOfs
        '
        Me.lblOfs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblOfs.Location = New System.Drawing.Point(3, 3)
        Me.lblOfs.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblOfs.Name = "lblOfs"
        Me.lblOfs.Size = New System.Drawing.Size(117, 20)
        Me.lblOfs.TabIndex = 27
        Me.lblOfs.Text = "PWM offset"
        Me.lblOfs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel7
        '
        Me.Panel7.Controls.Add(Me.nudSpMax)
        Me.Panel7.Controls.Add(Me.nudSpMin)
        Me.Panel7.Controls.Add(Me.Label1)
        Me.Panel7.Location = New System.Drawing.Point(3, 238)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(223, 24)
        Me.Panel7.TabIndex = 9
        '
        'nudSpMax
        '
        Me.nudSpMax.BackColor = System.Drawing.Color.Black
        Me.nudSpMax.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudSpMax.Location = New System.Drawing.Point(170, 3)
        Me.nudSpMax.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudSpMax.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudSpMax.Name = "nudSpMax"
        Me.nudSpMax.Size = New System.Drawing.Size(48, 20)
        Me.nudSpMax.TabIndex = 20
        Me.nudSpMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudSpMax.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudSpMin
        '
        Me.nudSpMin.BackColor = System.Drawing.Color.Black
        Me.nudSpMin.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudSpMin.Location = New System.Drawing.Point(117, 3)
        Me.nudSpMin.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudSpMin.Maximum = New Decimal(New Integer() {1024, 0, 0, 0})
        Me.nudSpMin.Name = "nudSpMin"
        Me.nudSpMin.Size = New System.Drawing.Size(48, 20)
        Me.nudSpMin.TabIndex = 19
        Me.nudSpMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudSpMin.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'Label1
        '
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label1.Location = New System.Drawing.Point(3, 3)
        Me.Label1.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(117, 20)
        Me.Label1.TabIndex = 18
        Me.Label1.Text = "Reference min/max"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel8
        '
        Me.Panel8.Controls.Add(Me.nudTpsMax)
        Me.Panel8.Controls.Add(Me.nudTpsMin)
        Me.Panel8.Controls.Add(Me.Label2)
        Me.Panel8.Location = New System.Drawing.Point(3, 268)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(223, 24)
        Me.Panel8.TabIndex = 10
        '
        'nudTpsMax
        '
        Me.nudTpsMax.BackColor = System.Drawing.Color.Black
        Me.nudTpsMax.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTpsMax.Location = New System.Drawing.Point(170, 3)
        Me.nudTpsMax.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTpsMax.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudTpsMax.Name = "nudTpsMax"
        Me.nudTpsMax.Size = New System.Drawing.Size(48, 20)
        Me.nudTpsMax.TabIndex = 22
        Me.nudTpsMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTpsMax.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudTpsMin
        '
        Me.nudTpsMin.BackColor = System.Drawing.Color.Black
        Me.nudTpsMin.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTpsMin.Location = New System.Drawing.Point(117, 3)
        Me.nudTpsMin.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTpsMin.Maximum = New Decimal(New Integer() {1024, 0, 0, 0})
        Me.nudTpsMin.Name = "nudTpsMin"
        Me.nudTpsMin.Size = New System.Drawing.Size(48, 20)
        Me.nudTpsMin.TabIndex = 21
        Me.nudTpsMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTpsMin.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'Label2
        '
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label2.Location = New System.Drawing.Point(3, 3)
        Me.Label2.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(117, 20)
        Me.Label2.TabIndex = 18
        Me.Label2.Text = "TPS min/max"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel19
        '
        Me.Panel19.Controls.Add(Me.cbBitPrm1)
        Me.Panel19.Controls.Add(Me.Label9)
        Me.Panel19.Controls.Add(Me.cbBitPrm0)
        Me.Panel19.Controls.Add(Me.Label5)
        Me.Panel19.Location = New System.Drawing.Point(269, 33)
        Me.Panel19.Name = "Panel19"
        Me.Panel19.Size = New System.Drawing.Size(223, 45)
        Me.Panel19.TabIndex = 11
        '
        'cbBitPrm0
        '
        Me.cbBitPrm0.AutoCheck = False
        Me.cbBitPrm0.AutoSize = True
        Me.cbBitPrm0.Location = New System.Drawing.Point(117, 4)
        Me.cbBitPrm0.Name = "cbBitPrm0"
        Me.cbBitPrm0.Size = New System.Drawing.Size(56, 17)
        Me.cbBitPrm0.TabIndex = 23
        Me.cbBitPrm0.Text = "Active"
        Me.cbBitPrm0.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label5.Location = New System.Drawing.Point(3, 3)
        Me.Label5.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(115, 17)
        Me.Label5.TabIndex = 25
        Me.Label5.Text = "TPS reference table"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'pnlTable
        '
        Me.pnlTable.Controls.Add(Me.nudTblPos15)
        Me.pnlTable.Controls.Add(Me.nudTblSp15)
        Me.pnlTable.Controls.Add(Me.nudTblPos7)
        Me.pnlTable.Controls.Add(Me.nudTblSp7)
        Me.pnlTable.Controls.Add(Me.nudTblPos14)
        Me.pnlTable.Controls.Add(Me.nudTblSp14)
        Me.pnlTable.Controls.Add(Me.nudTblPos6)
        Me.pnlTable.Controls.Add(Me.nudTblSp6)
        Me.pnlTable.Controls.Add(Me.nudTblPos13)
        Me.pnlTable.Controls.Add(Me.nudTblSp13)
        Me.pnlTable.Controls.Add(Me.nudTblPos5)
        Me.pnlTable.Controls.Add(Me.nudTblSp5)
        Me.pnlTable.Controls.Add(Me.nudTblPos12)
        Me.pnlTable.Controls.Add(Me.nudTblSp12)
        Me.pnlTable.Controls.Add(Me.nudTblPos4)
        Me.pnlTable.Controls.Add(Me.nudTblSp4)
        Me.pnlTable.Controls.Add(Me.nudTblPos11)
        Me.pnlTable.Controls.Add(Me.nudTblSp11)
        Me.pnlTable.Controls.Add(Me.nudTblPos3)
        Me.pnlTable.Controls.Add(Me.nudTblSp3)
        Me.pnlTable.Controls.Add(Me.nudTblPos10)
        Me.pnlTable.Controls.Add(Me.nudTblSp10)
        Me.pnlTable.Controls.Add(Me.nudTblPos2)
        Me.pnlTable.Controls.Add(Me.nudTblSp2)
        Me.pnlTable.Controls.Add(Me.nudTblPos9)
        Me.pnlTable.Controls.Add(Me.nudTblSp9)
        Me.pnlTable.Controls.Add(Me.nudTblPos1)
        Me.pnlTable.Controls.Add(Me.nudTblSp1)
        Me.pnlTable.Controls.Add(Me.nudTblPos8)
        Me.pnlTable.Controls.Add(Me.nudTblSp8)
        Me.pnlTable.Controls.Add(Me.nudTblPos0)
        Me.pnlTable.Controls.Add(Me.nudTblSp0)
        Me.pnlTable.Controls.Add(Me.Label8)
        Me.pnlTable.Location = New System.Drawing.Point(269, 84)
        Me.pnlTable.Name = "pnlTable"
        Me.pnlTable.Size = New System.Drawing.Size(223, 208)
        Me.pnlTable.TabIndex = 12
        '
        'nudTblPos15
        '
        Me.nudTblPos15.BackColor = System.Drawing.Color.Black
        Me.nudTblPos15.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTblPos15.Location = New System.Drawing.Point(168, 185)
        Me.nudTblPos15.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTblPos15.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudTblPos15.Name = "nudTblPos15"
        Me.nudTblPos15.Size = New System.Drawing.Size(48, 20)
        Me.nudTblPos15.TabIndex = 55
        Me.nudTblPos15.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTblPos15.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudTblSp15
        '
        Me.nudTblSp15.BackColor = System.Drawing.Color.Black
        Me.nudTblSp15.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTblSp15.Location = New System.Drawing.Point(114, 185)
        Me.nudTblSp15.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTblSp15.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudTblSp15.Name = "nudTblSp15"
        Me.nudTblSp15.Size = New System.Drawing.Size(48, 20)
        Me.nudTblSp15.TabIndex = 54
        Me.nudTblSp15.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTblSp15.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudTblPos7
        '
        Me.nudTblPos7.BackColor = System.Drawing.Color.Black
        Me.nudTblPos7.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTblPos7.Location = New System.Drawing.Point(60, 185)
        Me.nudTblPos7.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTblPos7.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudTblPos7.Name = "nudTblPos7"
        Me.nudTblPos7.Size = New System.Drawing.Size(48, 20)
        Me.nudTblPos7.TabIndex = 39
        Me.nudTblPos7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTblPos7.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudTblSp7
        '
        Me.nudTblSp7.BackColor = System.Drawing.Color.Black
        Me.nudTblSp7.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTblSp7.Location = New System.Drawing.Point(6, 185)
        Me.nudTblSp7.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTblSp7.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudTblSp7.Name = "nudTblSp7"
        Me.nudTblSp7.Size = New System.Drawing.Size(48, 20)
        Me.nudTblSp7.TabIndex = 38
        Me.nudTblSp7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTblSp7.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudTblPos14
        '
        Me.nudTblPos14.BackColor = System.Drawing.Color.Black
        Me.nudTblPos14.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTblPos14.Location = New System.Drawing.Point(168, 162)
        Me.nudTblPos14.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTblPos14.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudTblPos14.Name = "nudTblPos14"
        Me.nudTblPos14.Size = New System.Drawing.Size(48, 20)
        Me.nudTblPos14.TabIndex = 53
        Me.nudTblPos14.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTblPos14.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudTblSp14
        '
        Me.nudTblSp14.BackColor = System.Drawing.Color.Black
        Me.nudTblSp14.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTblSp14.Location = New System.Drawing.Point(114, 162)
        Me.nudTblSp14.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTblSp14.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudTblSp14.Name = "nudTblSp14"
        Me.nudTblSp14.Size = New System.Drawing.Size(48, 20)
        Me.nudTblSp14.TabIndex = 52
        Me.nudTblSp14.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTblSp14.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudTblPos6
        '
        Me.nudTblPos6.BackColor = System.Drawing.Color.Black
        Me.nudTblPos6.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTblPos6.Location = New System.Drawing.Point(60, 162)
        Me.nudTblPos6.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTblPos6.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudTblPos6.Name = "nudTblPos6"
        Me.nudTblPos6.Size = New System.Drawing.Size(48, 20)
        Me.nudTblPos6.TabIndex = 37
        Me.nudTblPos6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTblPos6.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudTblSp6
        '
        Me.nudTblSp6.BackColor = System.Drawing.Color.Black
        Me.nudTblSp6.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTblSp6.Location = New System.Drawing.Point(6, 162)
        Me.nudTblSp6.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTblSp6.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudTblSp6.Name = "nudTblSp6"
        Me.nudTblSp6.Size = New System.Drawing.Size(48, 20)
        Me.nudTblSp6.TabIndex = 36
        Me.nudTblSp6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTblSp6.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudTblPos13
        '
        Me.nudTblPos13.BackColor = System.Drawing.Color.Black
        Me.nudTblPos13.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTblPos13.Location = New System.Drawing.Point(168, 139)
        Me.nudTblPos13.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTblPos13.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudTblPos13.Name = "nudTblPos13"
        Me.nudTblPos13.Size = New System.Drawing.Size(48, 20)
        Me.nudTblPos13.TabIndex = 51
        Me.nudTblPos13.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTblPos13.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudTblSp13
        '
        Me.nudTblSp13.BackColor = System.Drawing.Color.Black
        Me.nudTblSp13.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTblSp13.Location = New System.Drawing.Point(114, 139)
        Me.nudTblSp13.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTblSp13.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudTblSp13.Name = "nudTblSp13"
        Me.nudTblSp13.Size = New System.Drawing.Size(48, 20)
        Me.nudTblSp13.TabIndex = 50
        Me.nudTblSp13.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTblSp13.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudTblPos5
        '
        Me.nudTblPos5.BackColor = System.Drawing.Color.Black
        Me.nudTblPos5.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTblPos5.Location = New System.Drawing.Point(60, 139)
        Me.nudTblPos5.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTblPos5.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudTblPos5.Name = "nudTblPos5"
        Me.nudTblPos5.Size = New System.Drawing.Size(48, 20)
        Me.nudTblPos5.TabIndex = 35
        Me.nudTblPos5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTblPos5.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudTblSp5
        '
        Me.nudTblSp5.BackColor = System.Drawing.Color.Black
        Me.nudTblSp5.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTblSp5.Location = New System.Drawing.Point(6, 139)
        Me.nudTblSp5.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTblSp5.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudTblSp5.Name = "nudTblSp5"
        Me.nudTblSp5.Size = New System.Drawing.Size(48, 20)
        Me.nudTblSp5.TabIndex = 34
        Me.nudTblSp5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTblSp5.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudTblPos12
        '
        Me.nudTblPos12.BackColor = System.Drawing.Color.Black
        Me.nudTblPos12.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTblPos12.Location = New System.Drawing.Point(168, 116)
        Me.nudTblPos12.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTblPos12.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudTblPos12.Name = "nudTblPos12"
        Me.nudTblPos12.Size = New System.Drawing.Size(48, 20)
        Me.nudTblPos12.TabIndex = 49
        Me.nudTblPos12.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTblPos12.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudTblSp12
        '
        Me.nudTblSp12.BackColor = System.Drawing.Color.Black
        Me.nudTblSp12.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTblSp12.Location = New System.Drawing.Point(114, 116)
        Me.nudTblSp12.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTblSp12.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudTblSp12.Name = "nudTblSp12"
        Me.nudTblSp12.Size = New System.Drawing.Size(48, 20)
        Me.nudTblSp12.TabIndex = 48
        Me.nudTblSp12.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTblSp12.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudTblPos4
        '
        Me.nudTblPos4.BackColor = System.Drawing.Color.Black
        Me.nudTblPos4.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTblPos4.Location = New System.Drawing.Point(60, 116)
        Me.nudTblPos4.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTblPos4.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudTblPos4.Name = "nudTblPos4"
        Me.nudTblPos4.Size = New System.Drawing.Size(48, 20)
        Me.nudTblPos4.TabIndex = 33
        Me.nudTblPos4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTblPos4.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudTblSp4
        '
        Me.nudTblSp4.BackColor = System.Drawing.Color.Black
        Me.nudTblSp4.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTblSp4.Location = New System.Drawing.Point(6, 116)
        Me.nudTblSp4.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTblSp4.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudTblSp4.Name = "nudTblSp4"
        Me.nudTblSp4.Size = New System.Drawing.Size(48, 20)
        Me.nudTblSp4.TabIndex = 32
        Me.nudTblSp4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTblSp4.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudTblPos11
        '
        Me.nudTblPos11.BackColor = System.Drawing.Color.Black
        Me.nudTblPos11.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTblPos11.Location = New System.Drawing.Point(168, 93)
        Me.nudTblPos11.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTblPos11.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudTblPos11.Name = "nudTblPos11"
        Me.nudTblPos11.Size = New System.Drawing.Size(48, 20)
        Me.nudTblPos11.TabIndex = 47
        Me.nudTblPos11.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTblPos11.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudTblSp11
        '
        Me.nudTblSp11.BackColor = System.Drawing.Color.Black
        Me.nudTblSp11.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTblSp11.Location = New System.Drawing.Point(114, 93)
        Me.nudTblSp11.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTblSp11.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudTblSp11.Name = "nudTblSp11"
        Me.nudTblSp11.Size = New System.Drawing.Size(48, 20)
        Me.nudTblSp11.TabIndex = 46
        Me.nudTblSp11.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTblSp11.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudTblPos3
        '
        Me.nudTblPos3.BackColor = System.Drawing.Color.Black
        Me.nudTblPos3.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTblPos3.Location = New System.Drawing.Point(60, 93)
        Me.nudTblPos3.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTblPos3.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudTblPos3.Name = "nudTblPos3"
        Me.nudTblPos3.Size = New System.Drawing.Size(48, 20)
        Me.nudTblPos3.TabIndex = 31
        Me.nudTblPos3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTblPos3.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudTblSp3
        '
        Me.nudTblSp3.BackColor = System.Drawing.Color.Black
        Me.nudTblSp3.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTblSp3.Location = New System.Drawing.Point(6, 93)
        Me.nudTblSp3.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTblSp3.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudTblSp3.Name = "nudTblSp3"
        Me.nudTblSp3.Size = New System.Drawing.Size(48, 20)
        Me.nudTblSp3.TabIndex = 30
        Me.nudTblSp3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTblSp3.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudTblPos10
        '
        Me.nudTblPos10.BackColor = System.Drawing.Color.Black
        Me.nudTblPos10.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTblPos10.Location = New System.Drawing.Point(168, 70)
        Me.nudTblPos10.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTblPos10.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudTblPos10.Name = "nudTblPos10"
        Me.nudTblPos10.Size = New System.Drawing.Size(48, 20)
        Me.nudTblPos10.TabIndex = 45
        Me.nudTblPos10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTblPos10.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudTblSp10
        '
        Me.nudTblSp10.BackColor = System.Drawing.Color.Black
        Me.nudTblSp10.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTblSp10.Location = New System.Drawing.Point(114, 70)
        Me.nudTblSp10.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTblSp10.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudTblSp10.Name = "nudTblSp10"
        Me.nudTblSp10.Size = New System.Drawing.Size(48, 20)
        Me.nudTblSp10.TabIndex = 44
        Me.nudTblSp10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTblSp10.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudTblPos2
        '
        Me.nudTblPos2.BackColor = System.Drawing.Color.Black
        Me.nudTblPos2.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTblPos2.Location = New System.Drawing.Point(60, 70)
        Me.nudTblPos2.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTblPos2.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudTblPos2.Name = "nudTblPos2"
        Me.nudTblPos2.Size = New System.Drawing.Size(48, 20)
        Me.nudTblPos2.TabIndex = 29
        Me.nudTblPos2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTblPos2.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudTblSp2
        '
        Me.nudTblSp2.BackColor = System.Drawing.Color.Black
        Me.nudTblSp2.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTblSp2.Location = New System.Drawing.Point(6, 70)
        Me.nudTblSp2.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTblSp2.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudTblSp2.Name = "nudTblSp2"
        Me.nudTblSp2.Size = New System.Drawing.Size(48, 20)
        Me.nudTblSp2.TabIndex = 28
        Me.nudTblSp2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTblSp2.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudTblPos9
        '
        Me.nudTblPos9.BackColor = System.Drawing.Color.Black
        Me.nudTblPos9.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTblPos9.Location = New System.Drawing.Point(168, 47)
        Me.nudTblPos9.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTblPos9.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudTblPos9.Name = "nudTblPos9"
        Me.nudTblPos9.Size = New System.Drawing.Size(48, 20)
        Me.nudTblPos9.TabIndex = 43
        Me.nudTblPos9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTblPos9.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudTblSp9
        '
        Me.nudTblSp9.BackColor = System.Drawing.Color.Black
        Me.nudTblSp9.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTblSp9.Location = New System.Drawing.Point(114, 47)
        Me.nudTblSp9.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTblSp9.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudTblSp9.Name = "nudTblSp9"
        Me.nudTblSp9.Size = New System.Drawing.Size(48, 20)
        Me.nudTblSp9.TabIndex = 42
        Me.nudTblSp9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTblSp9.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudTblPos1
        '
        Me.nudTblPos1.BackColor = System.Drawing.Color.Black
        Me.nudTblPos1.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTblPos1.Location = New System.Drawing.Point(60, 47)
        Me.nudTblPos1.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTblPos1.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudTblPos1.Name = "nudTblPos1"
        Me.nudTblPos1.Size = New System.Drawing.Size(48, 20)
        Me.nudTblPos1.TabIndex = 27
        Me.nudTblPos1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTblPos1.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudTblSp1
        '
        Me.nudTblSp1.BackColor = System.Drawing.Color.Black
        Me.nudTblSp1.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTblSp1.Location = New System.Drawing.Point(6, 47)
        Me.nudTblSp1.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTblSp1.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudTblSp1.Name = "nudTblSp1"
        Me.nudTblSp1.Size = New System.Drawing.Size(48, 20)
        Me.nudTblSp1.TabIndex = 26
        Me.nudTblSp1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTblSp1.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudTblPos8
        '
        Me.nudTblPos8.BackColor = System.Drawing.Color.Black
        Me.nudTblPos8.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTblPos8.Location = New System.Drawing.Point(168, 24)
        Me.nudTblPos8.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTblPos8.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudTblPos8.Name = "nudTblPos8"
        Me.nudTblPos8.Size = New System.Drawing.Size(48, 20)
        Me.nudTblPos8.TabIndex = 41
        Me.nudTblPos8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTblPos8.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudTblSp8
        '
        Me.nudTblSp8.BackColor = System.Drawing.Color.Black
        Me.nudTblSp8.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTblSp8.Location = New System.Drawing.Point(114, 24)
        Me.nudTblSp8.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTblSp8.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudTblSp8.Name = "nudTblSp8"
        Me.nudTblSp8.Size = New System.Drawing.Size(48, 20)
        Me.nudTblSp8.TabIndex = 40
        Me.nudTblSp8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTblSp8.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudTblPos0
        '
        Me.nudTblPos0.BackColor = System.Drawing.Color.Black
        Me.nudTblPos0.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTblPos0.Location = New System.Drawing.Point(60, 24)
        Me.nudTblPos0.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTblPos0.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudTblPos0.Name = "nudTblPos0"
        Me.nudTblPos0.Size = New System.Drawing.Size(48, 20)
        Me.nudTblPos0.TabIndex = 25
        Me.nudTblPos0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTblPos0.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudTblSp0
        '
        Me.nudTblSp0.BackColor = System.Drawing.Color.Black
        Me.nudTblSp0.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTblSp0.Location = New System.Drawing.Point(6, 24)
        Me.nudTblSp0.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTblSp0.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudTblSp0.Name = "nudTblSp0"
        Me.nudTblSp0.Size = New System.Drawing.Size(48, 20)
        Me.nudTblSp0.TabIndex = 24
        Me.nudTblSp0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTblSp0.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'Label8
        '
        Me.Label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label8.Location = New System.Drawing.Point(6, 3)
        Me.Label8.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(210, 22)
        Me.Label8.TabIndex = 22
        Me.Label8.Text = "Reference in/out"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel11
        '
        Me.Panel11.Controls.Add(Me.Panel21)
        Me.Panel11.Location = New System.Drawing.Point(498, 3)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(223, 50)
        Me.Panel11.TabIndex = 13
        '
        'Panel21
        '
        Me.Panel21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel21.Controls.Add(Me.rbFF)
        Me.Panel21.Controls.Add(Me.rbAmp)
        Me.Panel21.Controls.Add(Me.Label6)
        Me.Panel21.Controls.Add(Me.rbP)
        Me.Panel21.Controls.Add(Me.rbD)
        Me.Panel21.Controls.Add(Me.rbI)
        Me.Panel21.Location = New System.Drawing.Point(3, 4)
        Me.Panel21.Name = "Panel21"
        Me.Panel21.Size = New System.Drawing.Size(217, 44)
        Me.Panel21.TabIndex = 39
        '
        'rbFF
        '
        Me.rbFF.AutoSize = True
        Me.rbFF.Location = New System.Drawing.Point(119, 23)
        Me.rbFF.Name = "rbFF"
        Me.rbFF.Size = New System.Drawing.Size(37, 17)
        Me.rbFF.TabIndex = 59
        Me.rbFF.TabStop = True
        Me.rbFF.Text = "FF"
        Me.rbFF.UseVisualStyleBackColor = True
        '
        'rbAmp
        '
        Me.rbAmp.AutoSize = True
        Me.rbAmp.Location = New System.Drawing.Point(162, 23)
        Me.rbAmp.Name = "rbAmp"
        Me.rbAmp.Size = New System.Drawing.Size(46, 17)
        Me.rbAmp.TabIndex = 60
        Me.rbAmp.TabStop = True
        Me.rbAmp.Text = "Amp"
        Me.rbAmp.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(2, 2)
        Me.Label6.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(161, 18)
        Me.Label6.TabIndex = 33
        Me.Label6.Text = "TREND - Output last trend pen"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'rbP
        '
        Me.rbP.AutoSize = True
        Me.rbP.Location = New System.Drawing.Point(5, 23)
        Me.rbP.Name = "rbP"
        Me.rbP.Size = New System.Drawing.Size(32, 17)
        Me.rbP.TabIndex = 56
        Me.rbP.TabStop = True
        Me.rbP.Text = "P"
        Me.rbP.UseVisualStyleBackColor = True
        '
        'rbD
        '
        Me.rbD.AutoSize = True
        Me.rbD.Location = New System.Drawing.Point(81, 23)
        Me.rbD.Name = "rbD"
        Me.rbD.Size = New System.Drawing.Size(33, 17)
        Me.rbD.TabIndex = 58
        Me.rbD.TabStop = True
        Me.rbD.Text = "D"
        Me.rbD.UseVisualStyleBackColor = True
        '
        'rbI
        '
        Me.rbI.AutoSize = True
        Me.rbI.Location = New System.Drawing.Point(43, 23)
        Me.rbI.Name = "rbI"
        Me.rbI.Size = New System.Drawing.Size(28, 17)
        Me.rbI.TabIndex = 57
        Me.rbI.TabStop = True
        Me.rbI.Text = "I"
        Me.rbI.UseVisualStyleBackColor = True
        '
        'Panel12
        '
        Me.Panel12.Controls.Add(Me.pnlClrPen1)
        Me.Panel12.Controls.Add(Me.cbUsePen1)
        Me.Panel12.Location = New System.Drawing.Point(498, 59)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(223, 21)
        Me.Panel12.TabIndex = 14
        '
        'pnlClrPen1
        '
        Me.pnlClrPen1.BackColor = Global.TPStuner.My.MySettings.Default.clrTrendPen1
        Me.pnlClrPen1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlClrPen1.DataBindings.Add(New System.Windows.Forms.Binding("BackColor", Global.TPStuner.My.MySettings.Default, "clrTrendPen1", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.pnlClrPen1.Location = New System.Drawing.Point(123, 4)
        Me.pnlClrPen1.Name = "pnlClrPen1"
        Me.pnlClrPen1.Size = New System.Drawing.Size(32, 13)
        Me.pnlClrPen1.TabIndex = 62
        '
        'cbUsePen1
        '
        Me.cbUsePen1.AutoSize = True
        Me.cbUsePen1.Checked = Global.TPStuner.My.MySettings.Default.bUseTrendPen1
        Me.cbUsePen1.CheckState = System.Windows.Forms.CheckState.Checked
        Me.cbUsePen1.DataBindings.Add(New System.Windows.Forms.Binding("Checked", Global.TPStuner.My.MySettings.Default, "bUseTrendPen1", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.cbUsePen1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.TPStuner.My.MySettings.Default, "sTextPen1", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.cbUsePen1.Location = New System.Drawing.Point(6, 3)
        Me.cbUsePen1.Name = "cbUsePen1"
        Me.cbUsePen1.Size = New System.Drawing.Size(84, 17)
        Me.cbUsePen1.TabIndex = 61
        Me.cbUsePen1.Text = Global.TPStuner.My.MySettings.Default.sTextPen1
        Me.cbUsePen1.UseVisualStyleBackColor = True
        '
        'Panel10
        '
        Me.Panel10.Controls.Add(Me.pnlClrPen2)
        Me.Panel10.Controls.Add(Me.cbUsePen2)
        Me.Panel10.Location = New System.Drawing.Point(498, 86)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(223, 21)
        Me.Panel10.TabIndex = 25
        '
        'pnlClrPen2
        '
        Me.pnlClrPen2.BackColor = Global.TPStuner.My.MySettings.Default.clrTrendPen2
        Me.pnlClrPen2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlClrPen2.DataBindings.Add(New System.Windows.Forms.Binding("BackColor", Global.TPStuner.My.MySettings.Default, "clrTrendPen2", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.pnlClrPen2.Location = New System.Drawing.Point(123, 4)
        Me.pnlClrPen2.Name = "pnlClrPen2"
        Me.pnlClrPen2.Size = New System.Drawing.Size(32, 13)
        Me.pnlClrPen2.TabIndex = 64
        '
        'cbUsePen2
        '
        Me.cbUsePen2.AutoSize = True
        Me.cbUsePen2.Checked = Global.TPStuner.My.MySettings.Default.bUseTrendPen2
        Me.cbUsePen2.CheckState = System.Windows.Forms.CheckState.Checked
        Me.cbUsePen2.DataBindings.Add(New System.Windows.Forms.Binding("Checked", Global.TPStuner.My.MySettings.Default, "bUseTrendPen2", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.cbUsePen2.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.TPStuner.My.MySettings.Default, "sTextPen2", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.cbUsePen2.Location = New System.Drawing.Point(6, 3)
        Me.cbUsePen2.Name = "cbUsePen2"
        Me.cbUsePen2.Size = New System.Drawing.Size(84, 17)
        Me.cbUsePen2.TabIndex = 63
        Me.cbUsePen2.Text = Global.TPStuner.My.MySettings.Default.sTextPen2
        Me.cbUsePen2.UseVisualStyleBackColor = True
        '
        'Panel14
        '
        Me.Panel14.Controls.Add(Me.pnlClrPen3)
        Me.Panel14.Controls.Add(Me.cbUsePen3)
        Me.Panel14.Location = New System.Drawing.Point(498, 113)
        Me.Panel14.Name = "Panel14"
        Me.Panel14.Size = New System.Drawing.Size(223, 21)
        Me.Panel14.TabIndex = 15
        '
        'pnlClrPen3
        '
        Me.pnlClrPen3.BackColor = Global.TPStuner.My.MySettings.Default.clrTrendPen3
        Me.pnlClrPen3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlClrPen3.DataBindings.Add(New System.Windows.Forms.Binding("BackColor", Global.TPStuner.My.MySettings.Default, "clrTrendPen3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.pnlClrPen3.Location = New System.Drawing.Point(123, 4)
        Me.pnlClrPen3.Name = "pnlClrPen3"
        Me.pnlClrPen3.Size = New System.Drawing.Size(32, 13)
        Me.pnlClrPen3.TabIndex = 66
        '
        'cbUsePen3
        '
        Me.cbUsePen3.AutoSize = True
        Me.cbUsePen3.Checked = Global.TPStuner.My.MySettings.Default.bUseTrendPen3
        Me.cbUsePen3.CheckState = System.Windows.Forms.CheckState.Checked
        Me.cbUsePen3.DataBindings.Add(New System.Windows.Forms.Binding("Checked", Global.TPStuner.My.MySettings.Default, "bUseTrendPen3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.cbUsePen3.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.TPStuner.My.MySettings.Default, "sTextPen3", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.cbUsePen3.Location = New System.Drawing.Point(6, 3)
        Me.cbUsePen3.Name = "cbUsePen3"
        Me.cbUsePen3.Size = New System.Drawing.Size(90, 17)
        Me.cbUsePen3.TabIndex = 65
        Me.cbUsePen3.Text = Global.TPStuner.My.MySettings.Default.sTextPen3
        Me.cbUsePen3.UseVisualStyleBackColor = True
        '
        'Panel16
        '
        Me.Panel16.Controls.Add(Me.pnlClrPen4)
        Me.Panel16.Controls.Add(Me.cbUsePen4)
        Me.Panel16.Location = New System.Drawing.Point(498, 140)
        Me.Panel16.Name = "Panel16"
        Me.Panel16.Size = New System.Drawing.Size(223, 21)
        Me.Panel16.TabIndex = 16
        '
        'pnlClrPen4
        '
        Me.pnlClrPen4.BackColor = Global.TPStuner.My.MySettings.Default.clrTrendPen4
        Me.pnlClrPen4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlClrPen4.DataBindings.Add(New System.Windows.Forms.Binding("BackColor", Global.TPStuner.My.MySettings.Default, "clrTrendPen4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.pnlClrPen4.Location = New System.Drawing.Point(123, 4)
        Me.pnlClrPen4.Name = "pnlClrPen4"
        Me.pnlClrPen4.Size = New System.Drawing.Size(32, 13)
        Me.pnlClrPen4.TabIndex = 68
        '
        'cbUsePen4
        '
        Me.cbUsePen4.AutoSize = True
        Me.cbUsePen4.Checked = Global.TPStuner.My.MySettings.Default.bUseTrendPen4
        Me.cbUsePen4.CheckState = System.Windows.Forms.CheckState.Checked
        Me.cbUsePen4.DataBindings.Add(New System.Windows.Forms.Binding("Checked", Global.TPStuner.My.MySettings.Default, "bUseTrendPen4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.cbUsePen4.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.TPStuner.My.MySettings.Default, "sTextPen4", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.cbUsePen4.Location = New System.Drawing.Point(6, 3)
        Me.cbUsePen4.Name = "cbUsePen4"
        Me.cbUsePen4.Size = New System.Drawing.Size(86, 17)
        Me.cbUsePen4.TabIndex = 67
        Me.cbUsePen4.Text = Global.TPStuner.My.MySettings.Default.sTextPen4
        Me.cbUsePen4.UseVisualStyleBackColor = True
        '
        'Panel18
        '
        Me.Panel18.Controls.Add(Me.pnlClrPen5)
        Me.Panel18.Controls.Add(Me.cbUsePen5)
        Me.Panel18.Location = New System.Drawing.Point(498, 167)
        Me.Panel18.Name = "Panel18"
        Me.Panel18.Size = New System.Drawing.Size(223, 21)
        Me.Panel18.TabIndex = 17
        '
        'pnlClrPen5
        '
        Me.pnlClrPen5.BackColor = Global.TPStuner.My.MySettings.Default.clrTrendPen5
        Me.pnlClrPen5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlClrPen5.DataBindings.Add(New System.Windows.Forms.Binding("BackColor", Global.TPStuner.My.MySettings.Default, "clrTrendPen5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.pnlClrPen5.Location = New System.Drawing.Point(123, 4)
        Me.pnlClrPen5.Name = "pnlClrPen5"
        Me.pnlClrPen5.Size = New System.Drawing.Size(32, 13)
        Me.pnlClrPen5.TabIndex = 70
        '
        'cbUsePen5
        '
        Me.cbUsePen5.AutoSize = True
        Me.cbUsePen5.Checked = Global.TPStuner.My.MySettings.Default.bUseTrendPen5
        Me.cbUsePen5.DataBindings.Add(New System.Windows.Forms.Binding("Checked", Global.TPStuner.My.MySettings.Default, "bUseTrendPen5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.cbUsePen5.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.TPStuner.My.MySettings.Default, "sTextPen5", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.cbUsePen5.Location = New System.Drawing.Point(6, 3)
        Me.cbUsePen5.Name = "cbUsePen5"
        Me.cbUsePen5.Size = New System.Drawing.Size(80, 17)
        Me.cbUsePen5.TabIndex = 69
        Me.cbUsePen5.Text = Global.TPStuner.My.MySettings.Default.sTextPen5
        Me.cbUsePen5.UseVisualStyleBackColor = True
        '
        'btnOK
        '
        Me.btnOK.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnOK.Location = New System.Drawing.Point(319, 307)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(75, 23)
        Me.btnOK.TabIndex = 0
        Me.btnOK.Text = "OK"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'btnUpload
        '
        Me.btnUpload.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnUpload.Location = New System.Drawing.Point(562, 307)
        Me.btnUpload.Name = "btnUpload"
        Me.btnUpload.Size = New System.Drawing.Size(75, 23)
        Me.btnUpload.TabIndex = 3
        Me.btnUpload.Text = "Upload"
        Me.btnUpload.UseVisualStyleBackColor = True
        '
        'btnDownload
        '
        Me.btnDownload.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnDownload.Location = New System.Drawing.Point(643, 307)
        Me.btnDownload.Name = "btnDownload"
        Me.btnDownload.Size = New System.Drawing.Size(75, 23)
        Me.btnDownload.TabIndex = 4
        Me.btnDownload.Text = "Download"
        Me.btnDownload.UseVisualStyleBackColor = True
        '
        'clrDialog
        '
        Me.clrDialog.AnyColor = True
        '
        'btnSave
        '
        Me.btnSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSave.Location = New System.Drawing.Point(400, 307)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(75, 23)
        Me.btnSave.TabIndex = 1
        Me.btnSave.Text = "Save"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnReset.Location = New System.Drawing.Point(481, 307)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(75, 23)
        Me.btnReset.TabIndex = 2
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'cbBitPrm1
        '
        Me.cbBitPrm1.AutoCheck = False
        Me.cbBitPrm1.AutoSize = True
        Me.cbBitPrm1.Location = New System.Drawing.Point(117, 25)
        Me.cbBitPrm1.Name = "cbBitPrm1"
        Me.cbBitPrm1.Size = New System.Drawing.Size(56, 17)
        Me.cbBitPrm1.TabIndex = 26
        Me.cbBitPrm1.Text = "Active"
        Me.cbBitPrm1.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label9.Location = New System.Drawing.Point(3, 24)
        Me.Label9.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(115, 17)
        Me.Label9.TabIndex = 27
        Me.Label9.Text = "Reference WOT"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel13
        '
        Me.Panel13.Controls.Add(Me.nudDCerr)
        Me.Panel13.Controls.Add(Me.nudTpsAB)
        Me.Panel13.Controls.Add(Me.Label10)
        Me.Panel13.Location = New System.Drawing.Point(269, 3)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(223, 24)
        Me.Panel13.TabIndex = 26
        '
        'nudDCerr
        '
        Me.nudDCerr.BackColor = System.Drawing.Color.Black
        Me.nudDCerr.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudDCerr.Location = New System.Drawing.Point(170, 3)
        Me.nudDCerr.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudDCerr.Maximum = New Decimal(New Integer() {1280, 0, 0, 0})
        Me.nudDCerr.Name = "nudDCerr"
        Me.nudDCerr.Size = New System.Drawing.Size(48, 20)
        Me.nudDCerr.TabIndex = 22
        Me.nudDCerr.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudDCerr.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'nudTpsAB
        '
        Me.nudTpsAB.BackColor = System.Drawing.Color.Black
        Me.nudTpsAB.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.nudTpsAB.Location = New System.Drawing.Point(117, 3)
        Me.nudTpsAB.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.nudTpsAB.Maximum = New Decimal(New Integer() {1024, 0, 0, 0})
        Me.nudTpsAB.Name = "nudTpsAB"
        Me.nudTpsAB.Size = New System.Drawing.Size(48, 20)
        Me.nudTpsAB.TabIndex = 21
        Me.nudTpsAB.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudTpsAB.Value = New Decimal(New Integer() {1024, 0, 0, 0})
        '
        'Label10
        '
        Me.Label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label10.Location = New System.Drawing.Point(3, 3)
        Me.Label10.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(117, 20)
        Me.Label10.TabIndex = 18
        Me.Label10.Text = "LED TPS A+B/DCerr"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'frmSettings
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(730, 342)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.btnDownload)
        Me.Controls.Add(Me.flpSettings)
        Me.Controls.Add(Me.btnUpload)
        Me.Controls.Add(Me.btnOK)
        Me.DataBindings.Add(New System.Windows.Forms.Binding("Location", Global.TPStuner.My.MySettings.Default, "frmSettingPos", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Location = Global.TPStuner.My.MySettings.Default.frmSettingPos
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmSettings"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.Text = "TPStuner - Settings"
        Me.TopMost = True
        Me.flpSettings.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        CType(Me.nudPTsk, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudSSnd, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        CType(Me.nudKpInvNeg, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudKpInv, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel5.ResumeLayout(False)
        CType(Me.nudIWinMax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudIWin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudIMax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudKiInv, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel20.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        CType(Me.nudKpDNeg, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudKpD, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel9.ResumeLayout(False)
        CType(Me.nudKpFFNeg, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudKpFF, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel6.ResumeLayout(False)
        CType(Me.nudPwmOfs, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel7.ResumeLayout(False)
        CType(Me.nudSpMax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudSpMin, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel8.ResumeLayout(False)
        CType(Me.nudTpsMax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTpsMin, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel19.ResumeLayout(False)
        Me.Panel19.PerformLayout()
        Me.pnlTable.ResumeLayout(False)
        CType(Me.nudTblPos15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTblSp15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTblPos7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTblSp7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTblPos14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTblSp14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTblPos6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTblSp6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTblPos13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTblSp13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTblPos5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTblSp5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTblPos12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTblSp12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTblPos4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTblSp4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTblPos11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTblSp11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTblPos3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTblSp3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTblPos10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTblSp10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTblPos2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTblSp2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTblPos9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTblSp9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTblPos1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTblSp1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTblPos8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTblSp8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTblPos0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTblSp0, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel11.ResumeLayout(False)
        Me.Panel21.ResumeLayout(False)
        Me.Panel21.PerformLayout()
        Me.Panel12.ResumeLayout(False)
        Me.Panel12.PerformLayout()
        Me.Panel10.ResumeLayout(False)
        Me.Panel10.PerformLayout()
        Me.Panel14.ResumeLayout(False)
        Me.Panel14.PerformLayout()
        Me.Panel16.ResumeLayout(False)
        Me.Panel16.PerformLayout()
        Me.Panel18.ResumeLayout(False)
        Me.Panel18.PerformLayout()
        Me.Panel13.ResumeLayout(False)
        CType(Me.nudDCerr, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTpsAB, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents flpSettings As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents lblCom As System.Windows.Forms.Label
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents lblP As System.Windows.Forms.Label
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents lblI As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lblD As System.Windows.Forms.Label
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents lblOfs As System.Windows.Forms.Label
    Friend WithEvents pnlTable As System.Windows.Forms.Panel
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents btnUpload As System.Windows.Forms.Button
    Friend WithEvents btnDownload As System.Windows.Forms.Button
    Friend WithEvents nudPwmOfs As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudKpInvNeg As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudKpInv As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudIWin As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudIMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudKiInv As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudKpDNeg As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudKpD As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTblPos11 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTblSp11 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTblPos3 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTblSp3 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTblPos10 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTblSp10 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTblPos2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTblSp2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTblPos9 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTblSp9 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTblPos1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTblSp1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTblPos8 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTblSp8 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTblPos0 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTblSp0 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTblPos15 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTblSp15 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTblPos7 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTblSp7 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTblPos14 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTblSp14 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTblPos6 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTblSp6 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTblPos13 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTblSp13 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTblPos5 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTblSp5 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTblPos12 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTblSp12 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTblPos4 As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTblSp4 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents nudSpMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudSpMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel8 As System.Windows.Forms.Panel
    Friend WithEvents nudTpsMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTpsMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents nudSSnd As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Panel9 As System.Windows.Forms.Panel
    Friend WithEvents nudKpFFNeg As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudKpFF As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents nudPTsk As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents nudIWinMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents Panel11 As System.Windows.Forms.Panel
    Friend WithEvents clrDialog As System.Windows.Forms.ColorDialog
    Friend WithEvents rbAmp As System.Windows.Forms.RadioButton
    Friend WithEvents rbFF As System.Windows.Forms.RadioButton
    Friend WithEvents rbD As System.Windows.Forms.RadioButton
    Friend WithEvents rbI As System.Windows.Forms.RadioButton
    Friend WithEvents rbP As System.Windows.Forms.RadioButton
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Panel19 As System.Windows.Forms.Panel
    Friend WithEvents cbBitPrm0 As System.Windows.Forms.CheckBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Panel20 As System.Windows.Forms.Panel
    Friend WithEvents Panel21 As System.Windows.Forms.Panel
    Friend WithEvents Panel12 As System.Windows.Forms.Panel
    Friend WithEvents pnlClrPen1 As System.Windows.Forms.Panel
    Friend WithEvents cbUsePen1 As System.Windows.Forms.CheckBox
    Friend WithEvents Panel10 As System.Windows.Forms.Panel
    Friend WithEvents pnlClrPen2 As System.Windows.Forms.Panel
    Friend WithEvents cbUsePen2 As System.Windows.Forms.CheckBox
    Friend WithEvents Panel14 As System.Windows.Forms.Panel
    Friend WithEvents pnlClrPen3 As System.Windows.Forms.Panel
    Friend WithEvents cbUsePen3 As System.Windows.Forms.CheckBox
    Friend WithEvents Panel16 As System.Windows.Forms.Panel
    Friend WithEvents pnlClrPen4 As System.Windows.Forms.Panel
    Friend WithEvents cbUsePen4 As System.Windows.Forms.CheckBox
    Friend WithEvents Panel18 As System.Windows.Forms.Panel
    Friend WithEvents pnlClrPen5 As System.Windows.Forms.Panel
    Friend WithEvents cbUsePen5 As System.Windows.Forms.CheckBox
    Friend WithEvents cmbCom As System.Windows.Forms.ComboBox
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnReset As System.Windows.Forms.Button
    Friend WithEvents cbBitPrm1 As System.Windows.Forms.CheckBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Panel13 As System.Windows.Forms.Panel
    Friend WithEvents nudDCerr As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTpsAB As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label10 As System.Windows.Forms.Label
End Class
