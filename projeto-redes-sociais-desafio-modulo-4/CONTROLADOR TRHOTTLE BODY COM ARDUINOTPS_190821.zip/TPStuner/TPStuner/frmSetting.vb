﻿Imports System.IO.Ports

Public Class frmSettings



    Private Sub frmLoad(sender As Object, e As EventArgs) Handles MyBase.Load

        'addera bindning till parameter
        nudKpInv.DataBindings.Add(New Binding("Value", genTPS, "kpInv"))
        nudKpInvNeg.DataBindings.Add(New Binding("Value", genTPS, "kpInvNeg"))
        nudKiInv.DataBindings.Add(New Binding("Value", genTPS, "kiInv"))
        nudIMax.DataBindings.Add(New Binding("Value", genTPS, "iMax"))
        nudIWin.DataBindings.Add(New Binding("Value", genTPS, "iWin"))
        nudIWinMax.DataBindings.Add(New Binding("Value", genTPS, "iWinMax"))
        nudKpD.DataBindings.Add(New Binding("Value", genTPS, "kpD"))
        nudKpDNeg.DataBindings.Add(New Binding("Value", genTPS, "kpDNeg"))
        nudKpFF.DataBindings.Add(New Binding("Value", genTPS, "kpFF"))
        nudKpFFNeg.DataBindings.Add(New Binding("Value", genTPS, "kpFFNeg"))
        cbBitPrm0.DataBindings.Add(New Binding("Checked", genTPS, "bitPrm0", True, DataSourceUpdateMode.OnPropertyChanged))
        cbBitPrm1.DataBindings.Add(New Binding("Checked", genTPS, "bitPrm1", True, DataSourceUpdateMode.OnPropertyChanged))
        rbP.DataBindings.Add(New Binding("Checked", genTPS, "bitPrm2", True, DataSourceUpdateMode.OnPropertyChanged))
        rbI.DataBindings.Add(New Binding("Checked", genTPS, "bitPrm3", True, DataSourceUpdateMode.OnPropertyChanged))
        rbD.DataBindings.Add(New Binding("Checked", genTPS, "bitPrm4", True, DataSourceUpdateMode.OnPropertyChanged))
        rbFF.DataBindings.Add(New Binding("Checked", genTPS, "bitPrm5", True, DataSourceUpdateMode.OnPropertyChanged))
        rbAmp.DataBindings.Add(New Binding("Checked", genTPS, "bitPrm6", True, DataSourceUpdateMode.OnPropertyChanged))
        nudPwmOfs.DataBindings.Add(New Binding("Value", genTPS, "pwmOfs"))
        nudSpMin.DataBindings.Add(New Binding("Value", genTPS, "spMin"))
        nudSpMax.DataBindings.Add(New Binding("Value", genTPS, "spMax"))
        nudTpsMin.DataBindings.Add(New Binding("Value", genTPS, "tpsMin"))
        nudTpsMax.DataBindings.Add(New Binding("Value", genTPS, "tpsMax"))
        nudSSnd.DataBindings.Add(New Binding("Value", genTPS, "sSnd"))
        nudPTsk.DataBindings.Add(New Binding("Value", genTPS, "pTsk"))
        nudTpsAB.DataBindings.Add(New Binding("Value", genTPS, "tpsAB"))
        nudDCerr.DataBindings.Add(New Binding("Value", genTPS, "DCerr"))


        For Each o As Control In pnlTable.Controls
            If Microsoft.VisualBasic.Left(o.Name, 8) = "nudTblSp" Then
                o.DataBindings.Add(New Binding("Value", genTPS, "tblSp" & Microsoft.VisualBasic.Mid(o.Name, 9)))
            End If
            If Microsoft.VisualBasic.Left(o.Name, 9) = "nudTblPos" Then
                o.DataBindings.Add(New Binding("Value", genTPS, "tblPos" & Microsoft.VisualBasic.Mid(o.Name, 10)))
            End If

        Next

        Me.Size = My.Settings.frmSettingSize

        For Each s As String In SerialPort.GetPortNames()
            cmbCom.Items.Add(s)
        Next

        Dim index As Integer
        index = cmbCom.FindString(My.Settings.sComPort)
        cmbCom.SelectedIndex = index

    End Sub

    Private Sub frmClosing(sender As Object, e As EventArgs) Handles MyBase.FormClosing

        My.Settings.frmSettingSize = Me.Size

    End Sub

    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click
        Me.Close()
    End Sub

    Private Async Sub btnUpload_Click(sender As Object, e As EventArgs) Handles btnUpload.Click

        Await ParametersRead()

    End Sub

    Private Async Sub btnDownload_Click(sender As Object, e As EventArgs) Handles btnDownload.Click

        Await ParametersSave()

    End Sub


    Private Sub cbUsePen_CheckedChanged(sender As Object, e As EventArgs) Handles cbUsePen1.CheckedChanged, cbUsePen2.CheckedChanged, cbUsePen3.CheckedChanged, cbUsePen4.CheckedChanged, cbUsePen5.CheckedChanged

        With DirectCast(sender, CheckBox)
            Select Case Convert.ToInt32(Microsoft.VisualBasic.Right("0" & .Name, 1))
                Case 1
                    'My.Settings.bUseTrendPen1 = .Checked
                    genTrend.bUsePen(0) = .Checked
                Case 2
                    'My.Settings.bUseTrendPen2 = .Checked
                    genTrend.bUsePen(1) = .Checked
                Case 3
                    'My.Settings.bUseTrendPen3 = .Checked
                    genTrend.bUsePen(2) = .Checked
                Case 4
                    'My.Settings.bUseTrendPen4 = .Checked
                    genTrend.bUsePen(3) = .Checked
                Case 5
                    'My.Settings.bUseTrendPen5 = .Checked
                    genTrend.bUsePen(4) = .Checked
            End Select
        End With

        frmMain.dpnlInfo.Invalidate()

    End Sub

    Private Sub pnlClrPen_Click(sender As Object, e As EventArgs) Handles pnlClrPen1.Click, pnlClrPen2.Click, pnlClrPen3.Click, pnlClrPen4.Click, pnlClrPen5.Click
        Dim clr As Color

        With DirectCast(sender, Panel)

            clrDialog.Color = .BackColor
            If clrDialog.ShowDialog = Windows.Forms.DialogResult.Cancel Then Exit Sub
            clr = clrDialog.Color

            .BackColor = clr
            Select Case Convert.ToInt32(Microsoft.VisualBasic.Right(.Name, 1))
                Case 1
                    'My.Settings.clrTrendPen1 = .BackColor
                    genTrend.clrPen(0).Color = .BackColor
                Case 2
                    'My.Settings.clrTrendPen2 = .BackColor
                    genTrend.clrPen(1).Color = .BackColor
                Case 3
                    'My.Settings.clrTrendPen3 = .BackColor
                    genTrend.clrPen(2).Color = .BackColor
                Case 4
                    'My.Settings.clrTrendPen4 = .BackColor
                    genTrend.clrPen(3).Color = .BackColor
                Case 5
                    'My.Settings.clrTrendPen5 = .BackColor
                    genTrend.clrPen(4).Color = .BackColor
            End Select
        End With

        frmMain.dpnlInfo.Invalidate()

    End Sub

    Private Sub rbD_CheckedChanged(sender As Object, e As EventArgs) Handles rbP.CheckedChanged, rbI.CheckedChanged, rbD.CheckedChanged, rbFF.CheckedChanged, rbAmp.CheckedChanged
        With DirectCast(sender, RadioButton)
            If .Name <> "" And .Checked Then
                cbUsePen5.Text = "Pen 5 - " & .Text
                genTrend.sTextPen(4) = cbUsePen5.Text
            End If
        End With

        frmMain.dpnlInfo.Invalidate()

    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click

        My.Settings.frmMainSplitDist1 = frmMain.splitMain.SplitterDistance
        My.Settings.frmMainSplitDist2 = frmMain.splitView.SplitterDistance
        My.Settings.frmMainSize = frmMain.Size
        My.Settings.frmSettingSize = Me.Size
        My.Settings.Save()

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        My.Settings.Reset()

        Me.Size = My.Settings.frmSettingSize
        frmMain.Size = My.Settings.frmMainSize
        frmMain.splitMain.SplitterDistance = My.Settings.frmMainSplitDist1
        frmMain.splitView.SplitterDistance = My.Settings.frmMainSplitDist2

        cmbCom.Items.Clear()
        For Each s As String In SerialPort.GetPortNames()
            cmbCom.Items.Add(s)
        Next

        Dim index As Integer
        index = cmbCom.FindString(My.Settings.sComPort)
        cmbCom.SelectedIndex = index

    End Sub
End Class


