﻿'Imports TPStuner


Module _Module
    Public genTPS As New tps.value
    Public genComData As New tps.message
    Public genTrend As New tps.trend

    Public Sub ErrUnknownMsg(ex As Exception)

        MessageBox.Show("Unknow error in application!" & vbLf & vbLf & ex.StackTrace & vbLf & vbLf & ex.Message & vbLf & ex.HResult, "Unhandled Error", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1)

    End Sub

    Public Async Function ParametersRead() As Threading.Tasks.Task(Of Boolean)

        If Not genComData.comPort.IsOpen Then
            MsgBox("Comport is not open.", MsgBoxStyle.Exclamation)
            Return False
            Exit Function
        End If

        Await genComData.PrmRead()

        If genComData.newPrmOK Then
            genTPS.kpInv = BitConverter.ToInt16(genComData.output, 0)
            genTPS.kpInvNeg = BitConverter.ToInt16(genComData.output, 2)
            genTPS.kiInv = BitConverter.ToInt16(genComData.output, 4)
            genTPS.iMAx = BitConverter.ToInt16(genComData.output, 6)
            genTPS.iWin = BitConverter.ToInt16(genComData.output, 8)
            genTPS.iWinMax = BitConverter.ToInt16(genComData.output, 10)
            genTPS.tpsAB = BitConverter.ToInt16(genComData.output, 12)
            genTPS.kpD = BitConverter.ToInt16(genComData.output, 14)
            genTPS.kpDNeg = BitConverter.ToInt16(genComData.output, 16)
            genTPS.bitPrm = BitConverter.ToUInt16(genComData.output, 18)
            genTPS.pwmOfs = BitConverter.ToInt16(genComData.output, 20)

            genTPS.tblSp0 = BitConverter.ToInt16(genComData.output, 22)
            genTPS.tblSp1 = BitConverter.ToInt16(genComData.output, 22 + 2)
            genTPS.tblSp2 = BitConverter.ToInt16(genComData.output, 22 + 4)
            genTPS.tblSp3 = BitConverter.ToInt16(genComData.output, 22 + 6)
            genTPS.tblSp4 = BitConverter.ToInt16(genComData.output, 22 + 8)
            genTPS.tblSp5 = BitConverter.ToInt16(genComData.output, 22 + 10)
            genTPS.tblSp6 = BitConverter.ToInt16(genComData.output, 22 + 12)
            genTPS.tblSp7 = BitConverter.ToInt16(genComData.output, 22 + 14)
            genTPS.tblSp8 = BitConverter.ToInt16(genComData.output, 22 + 16)
            genTPS.tblSp9 = BitConverter.ToInt16(genComData.output, 22 + 18)
            genTPS.tblSp10 = BitConverter.ToInt16(genComData.output, 22 + 20)
            genTPS.tblSp11 = BitConverter.ToInt16(genComData.output, 22 + 22)
            genTPS.tblSp12 = BitConverter.ToInt16(genComData.output, 22 + 24)
            genTPS.tblSp13 = BitConverter.ToInt16(genComData.output, 22 + 26)
            genTPS.tblSp14 = BitConverter.ToInt16(genComData.output, 22 + 28)
            genTPS.tblSp15 = BitConverter.ToInt16(genComData.output, 22 + 30)

            genTPS.tblPos0 = BitConverter.ToInt16(genComData.output, 54)
            genTPS.tblPos1 = BitConverter.ToInt16(genComData.output, 54 + 2)
            genTPS.tblPos2 = BitConverter.ToInt16(genComData.output, 54 + 4)
            genTPS.tblPos3 = BitConverter.ToInt16(genComData.output, 54 + 6)
            genTPS.tblPos4 = BitConverter.ToInt16(genComData.output, 54 + 8)
            genTPS.tblPos5 = BitConverter.ToInt16(genComData.output, 54 + 10)
            genTPS.tblPos6 = BitConverter.ToInt16(genComData.output, 54 + 12)
            genTPS.tblPos7 = BitConverter.ToInt16(genComData.output, 54 + 14)
            genTPS.tblPos8 = BitConverter.ToInt16(genComData.output, 54 + 16)
            genTPS.tblPos9 = BitConverter.ToInt16(genComData.output, 54 + 18)
            genTPS.tblPos10 = BitConverter.ToInt16(genComData.output, 54 + 20)
            genTPS.tblPos11 = BitConverter.ToInt16(genComData.output, 54 + 22)
            genTPS.tblPos12 = BitConverter.ToInt16(genComData.output, 54 + 24)
            genTPS.tblPos13 = BitConverter.ToInt16(genComData.output, 54 + 26)
            genTPS.tblPos14 = BitConverter.ToInt16(genComData.output, 54 + 28)
            genTPS.tblPos15 = BitConverter.ToInt16(genComData.output, 54 + 30)

            genTPS.spMin = BitConverter.ToInt16(genComData.output, 86)
            genTPS.spMax = BitConverter.ToInt16(genComData.output, 88)
            genTPS.tpsMin = BitConverter.ToInt16(genComData.output, 90)
            genTPS.tpsMax = BitConverter.ToInt16(genComData.output, 92)

            genTPS.DCerr = BitConverter.ToInt16(genComData.output, 94)
            genTPS.kpFF = BitConverter.ToInt16(genComData.output, 96)
            genTPS.kpFFNeg = BitConverter.ToInt16(genComData.output, 98)

            genTPS.sSnd = BitConverter.ToInt32(genComData.output, 100)
            genTPS.pTsk = BitConverter.ToInt32(genComData.output, 104)


        Else
            MsgBox("Error reading parameter from unit.", MsgBoxStyle.Exclamation)
        End If

        genComData.cmdSend(tps.message.cmdComSend.txData)

        Return True

    End Function

    Public Async Function ParametersSave() As Threading.Tasks.Task(Of Boolean)

        If Not genComData.comPort.IsOpen Then
            MsgBox("Comport is not open.", MsgBoxStyle.Exclamation)
            Return False
            Exit Function
        End If

        Array.Copy(BitConverter.GetBytes(genTPS.kpInv), 0, genComData.output, 0, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.kpInvNeg), 0, genComData.output, 2, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.kiInv), 0, genComData.output, 4, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.iMAx), 0, genComData.output, 6, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.iWin), 0, genComData.output, 8, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.iWinMax), 0, genComData.output, 10, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.tpsAB), 0, genComData.output, 12, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.kpD), 0, genComData.output, 14, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.kpDNeg), 0, genComData.output, 16, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.bitPrm), 0, genComData.output, 18, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.pwmOfs), 0, genComData.output, 20, 2)

        Array.Copy(BitConverter.GetBytes(genTPS.tblSp0), 0, genComData.output, 22 + 0, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.tblSp1), 0, genComData.output, 22 + 2, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.tblSp2), 0, genComData.output, 22 + 4, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.tblSp3), 0, genComData.output, 22 + 6, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.tblSp4), 0, genComData.output, 22 + 8, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.tblSp5), 0, genComData.output, 22 + 10, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.tblSp6), 0, genComData.output, 22 + 12, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.tblSp7), 0, genComData.output, 22 + 14, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.tblSp8), 0, genComData.output, 22 + 16, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.tblSp9), 0, genComData.output, 22 + 18, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.tblSp10), 0, genComData.output, 22 + 20, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.tblSp11), 0, genComData.output, 22 + 22, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.tblSp12), 0, genComData.output, 22 + 24, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.tblSp13), 0, genComData.output, 22 + 26, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.tblSp14), 0, genComData.output, 22 + 28, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.tblSp15), 0, genComData.output, 22 + 30, 2)

        Array.Copy(BitConverter.GetBytes(genTPS.tblPos0), 0, genComData.output, 54 + 0, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.tblPos1), 0, genComData.output, 54 + 2, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.tblPos2), 0, genComData.output, 54 + 4, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.tblPos3), 0, genComData.output, 54 + 6, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.tblPos4), 0, genComData.output, 54 + 8, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.tblPos5), 0, genComData.output, 54 + 10, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.tblPos6), 0, genComData.output, 54 + 12, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.tblPos7), 0, genComData.output, 54 + 14, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.tblPos8), 0, genComData.output, 54 + 16, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.tblPos9), 0, genComData.output, 54 + 18, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.tblPos10), 0, genComData.output, 54 + 20, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.tblPos11), 0, genComData.output, 54 + 22, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.tblPos12), 0, genComData.output, 54 + 24, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.tblPos13), 0, genComData.output, 54 + 26, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.tblPos14), 0, genComData.output, 54 + 28, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.tblPos15), 0, genComData.output, 54 + 30, 2)

        Array.Copy(BitConverter.GetBytes(genTPS.spMin), 0, genComData.output, 86, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.spMax), 0, genComData.output, 88, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.tpsMin), 0, genComData.output, 90, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.tpsMax), 0, genComData.output, 92, 2)

        Array.Copy(BitConverter.GetBytes(genTPS.DCerr), 0, genComData.output, 94, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.kpFF), 0, genComData.output, 96, 2)
        Array.Copy(BitConverter.GetBytes(genTPS.kpFFNeg), 0, genComData.output, 98, 2)

        Array.Copy(BitConverter.GetBytes(genTPS.sSnd), 0, genComData.output, 100, 4)
        Array.Copy(BitConverter.GetBytes(genTPS.pTsk), 0, genComData.output, 104, 4)

        Await genComData.PrmWrite()

        genComData.cmdSend(tps.message.cmdComSend.txData)

        If Not genComData.newPrmOK Then
            MsgBox("Error writing parameters to unit.", MsgBoxStyle.Exclamation)
            Return False
        Else
            Return True
        End If

    End Function


    Public Sub PaintBg(e As PaintEventArgs, rct As Rectangle, clrBgTop As Color, clrBgBtm As Color, clrBrdTop As Color, clrBrdBtm As Color, bBg As Boolean, bBrd As Boolean)

        Dim lgBrush As New System.Drawing.Drawing2D.LinearGradientBrush(rct, clrBgTop, clrBgBtm, 60)
        Dim linePointTop() As Point = {New Point(rct.Left, rct.Height - 1), New Point(rct.Left, rct.Top), New Point(rct.Width - 1, rct.Top)}
        Dim linePointBtm() As Point = {New Point(rct.Left, rct.Height - 1), New Point(rct.Width - 1, rct.Height - 1), New Point(rct.Width - 1, rct.Top - 1)}

        If bBg Then e.Graphics.FillRegion(lgBrush, New Region(rct))
        If bBrd Then
            'e.Graphics.DrawRectangle(New Pen(clrBrdTop), New Rectangle(0, 0, rct.Width - 1, rct.Height - 1))
            e.Graphics.DrawLines(New Pen(clrBrdTop), linePointTop)
            e.Graphics.DrawLines(New Pen(clrBrdBtm), linePointBtm)
        End If
    End Sub

End Module

