﻿Imports System

Public Class DoubleBufferPanel

    Inherits Panel

    Public Sub New()
        ' Set the value of the double-buffering style bits to true.
        Me.SetStyle(ControlStyles.DoubleBuffer Or ControlStyles.UserPaint Or ControlStyles.AllPaintingInWmPaint, True)
        Me.UpdateStyles()
    End Sub

End Class



Public Class tps

    Public Class trend
        Public brd As Int32
        Public rec As Rectangle
        Public lgBrush As System.Drawing.Drawing2D.LinearGradientBrush
        Public dpen As System.Drawing.Pen

        Public dpnlTrend As DoubleBufferPanel
        Public Xpos As Int32
        Public Ypos As Int32
        Public Ygain As Single

        Public clrPen(4) As Pen
        Public bUsePen(4) As Boolean
        Public sTextPen(4) As String



    End Class


    Public Class message

        Public WithEvents comPort As System.IO.Ports.SerialPort
        Public input(32) As Byte
        Public output(107) As Byte
        Private tx() As Byte = {1, 2, 0, 3, 4}

        Public newValues As Boolean
        Public newTrend As Boolean
        Public newPrm As Boolean
        Public newPrmOK As Boolean

        Public cmdStopSend As Boolean

        Public Sub cmdSend(cmd As cmdComSend)

            If cmd = cmdComSend.txData Then cmdStopSend = False
            tx(2) = CByte(cmd)
            comPort.Write(tx, 0, 5)

        End Sub

        Public Async Function WaitComSend() As Threading.Tasks.Task(Of Boolean)

            Do
                Await Threading.Tasks.Task.Delay(100)
                Do While newValues Or comPort.BytesToRead > 0
                    Await Threading.Tasks.Task.Delay(100)
                Loop
                Await Threading.Tasks.Task.Delay(100)
            Loop While newValues Or comPort.BytesToRead > 0
            Return Not newValues

        End Function

        Public Async Function WaitPrmSend() As Threading.Tasks.Task(Of Boolean)
            Do While Not newPrm
                Await Threading.Tasks.Task.Delay(50)
            Loop
            Await Threading.Tasks.Task.Delay(100)
            newPrm = False
            Return True
        End Function

        Public Async Sub PortClose()
            If comPort.IsOpen Then
                cmdStopSend = True
                Await genComData.WaitComSend()
                comPort.Close()
            End If
        End Sub

        Public Sub PortOpen()
            If Not comPort.IsOpen Then
                comPort.PortName = My.Settings.sComPort
                cmdStopSend = False
                comPort.Open()
                cmdSend(cmdComSend.txData)
            End If
        End Sub

        Public Async Function PrmRead() As Threading.Tasks.Task(Of Boolean)
            newPrmOK = False
            cmdStopSend = True
            Await WaitComSend()
            cmdSend(tps.message.cmdComSend.txRead)
            Await WaitPrmSend()
            Return newPrmOK

        End Function
        Public Async Function PrmWrite() As Threading.Tasks.Task(Of Boolean)
            newPrmOK = False
            cmdStopSend = True
            Await WaitComSend()
            cmdSend(tps.message.cmdComSend.txWrite)
            Await WaitPrmSend()
            Return newPrmOK

        End Function


        Private Sub ComRecive(sender As Object, e As EventArgs) Handles comPort.DataReceived
            Static bValid As Boolean
            Static iRx(4), nbrByte, nbrIdx As System.Int32
            Dim iInput As System.Int32

            Try
                Do
                    iInput = comPort.ReadByte()
                    'inga pågående meddelande, vänta på h01, 06
                    If Not bValid Then
                        If iInput = cmdComSend.rxData Or iInput = cmdComSend.rxPrm Then
                            iRx(0) = iInput
                        ElseIf iRx(0) = cmdComSend.rxData Or iRx(0) = cmdComSend.rxPrm Then
                            'kontrollera tecken 2
                            If iInput = cmdComSend.rxTable Or iInput = cmdComSend.rxTrend Then
                                nbrByte = UBound(input)

                            ElseIf iInput = cmdComSend.txRead Then
                                nbrByte = UBound(output)

                            ElseIf iInput = cmdComSend.txWrite Then
                                nbrByte = 2
                                'skicka kontrolltecken och alla paramterar
                                comPort.Write(tx, 0, 2)
                                comPort.Write(output, 0, UBound(output) + 1)
                                comPort.Write(tx, 3, 2)
                            Else
                                iRx(0) = 0
                            End If

                            bValid = iRx(0) <> 0
                            iRx(1) = iInput : iRx(3) = 0 : iRx(4) = 0 : nbrIdx = 0

                        Else
                            iRx(0) = 0
                        End If

                        'ny trend data skickas
                    ElseIf iRx(1) = cmdComSend.rxTable Or iRx(1) = cmdComSend.rxTrend Then

                        'vänta tills alla bytes
                        If nbrIdx <= nbrByte Then
                            input(nbrIdx) = CByte(iInput)

                        ElseIf nbrIdx = nbrByte + 1 Then 'kontroll tecken 1
                            iRx(3) = iInput

                        ElseIf nbrIdx = nbrByte + 2 Then 'kontroll tecken 2
                            iRx(4) = iInput
                            If iRx(3) = cmdComSend.rxETX And iRx(4) = cmdComSend.rxEOT Then
                                newTrend = iRx(1) = cmdComSend.rxTrend
                                newValues = True
                            End If
                            bValid = False : iRx(0) = 0
                        Else
                            bValid = False : iRx(0) = 0 'bör alldrig hända
                        End If

                        'stega byte räknaren
                        nbrIdx += 1

                        'ta emot parameterdata
                    ElseIf iRx(1) = cmdComSend.txRead Then

                        If nbrIdx = 0 Then
                            If iInput <> cmdComSend.rxData Then bValid = False : iRx(0) = 0 : newPrm = True
                        ElseIf nbrIdx = 1 Then
                            If iInput <> cmdComSend.rxTable Then bValid = False : iRx(0) = 0 : newPrm = True

                            'vänta tills alla bytes
                        ElseIf nbrIdx <= nbrByte + 2 Then
                            output(nbrIdx - 2) = CByte(iInput)

                        ElseIf nbrIdx = nbrByte + 3 Then 'kontroll tecken 1
                            iRx(3) = iInput

                        ElseIf nbrIdx = nbrByte + 4 Then 'kontroll tecken 2
                            iRx(4) = iInput
                            If iRx(3) = cmdComSend.rxETX And iRx(4) = cmdComSend.rxEOT Then
                                newPrmOK = True
                            End If
                            bValid = False : iRx(0) = 0 : newPrm = True

                        Else
                            bValid = False : iRx(0) = 0 : newPrm = True 'bör alldrig hända
                        End If

                        'stega byte räknaren
                        nbrIdx += 1

                    ElseIf iRx(1) = cmdComSend.txWrite Then

                        If nbrIdx < nbrByte Then
                            output(nbrIdx) = CByte(iInput)
                        End If

                        'stega byte räknaren
                        nbrIdx += 1

                        If nbrIdx = nbrByte Then
                            If output(0) = cmdComSend.rxPrm And output(1) = cmdComSend.txWrite Then
                                newPrmOK = True
                            End If
                            bValid = False : iRx(0) = 0 : newPrm = True
                        End If
                    End If
                Loop Until iInput = -1

            Catch ex As Exception
                If ex.HResult <> -2147023901 Then ErrUnknownMsg(ex)
            End Try
        End Sub

        Enum cmdComSend
            rxData = 1
            rxTable = 2
            rxTrend = 30
            rxPrm = 6
            rxETX = 3
            rxEOT = 4
            txData = 5
            txRead = 14
            txWrite = 15
        End Enum


    End Class

    Public Class value
        Implements System.ComponentModel.INotifyPropertyChanged
        Public Event PropertyChanged(sender As Object, e As ComponentModel.PropertyChangedEventArgs) Implements ComponentModel.INotifyPropertyChanged.PropertyChanged

        Public clk As Byte

        Private _posSpRaw As Short
        <System.ComponentModel.Bindable(True)> Public Property posSpRaw As Short
            Get
                Return _posSpRaw
            End Get
            Set(value As Short)
                _posSpRaw = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("posSpRaw"))
            End Set
        End Property

        Private _posTpsARaw As Short
        <System.ComponentModel.Bindable(True)> Public Property posTpsARaw As Short
            Get
                Return _posTpsARaw
            End Get
            Set(value As Short)
                _posTpsARaw = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("posTpsARaw"))
            End Set
        End Property

        Private _posTpsBRaw As Short
        <System.ComponentModel.Bindable(True)> Public Property posTpsBRaw As Short
            Get
                Return _posTpsBRaw
            End Get
            Set(value As Short)
                _posTpsBRaw = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("posTpsBRaw"))
            End Set
        End Property

        Private _posAmpRaw As Short
        <System.ComponentModel.Bindable(True)> Public Property posAmpRaw As Short
            Get
                Return _posAmpRaw
            End Get
            Set(value As Short)
                _posAmpRaw = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("posAmpRaw"))
            End Set
        End Property

        Private _posSpIn As Short
        <System.ComponentModel.Bindable(True)> Public Property posSpIn As Short
            Get
                Return _posSpIn
            End Get
            Set(value As Short)
                _posSpIn = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("posSpIn"))
            End Set
        End Property

        Private _posSp As Short
        <System.ComponentModel.Bindable(True)> Public Property posSp As Short
            Get
                Return _posSp
            End Get
            Set(value As Short)
                _posSp = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("posSp"))
            End Set
        End Property

        Private _posTps As Short
        <System.ComponentModel.Bindable(True)> Public Property posTps As Short
            Get
                Return _posTps
            End Get
            Set(value As Short)
                _posTps = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("posTps"))
            End Set
        End Property

        Private _demPwm As Short
        <System.ComponentModel.Bindable(True)> Public Property demPwm As Short
            Get
                Return _demPwm
            End Get
            Set(value As Short)
                _demPwm = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("demPwm"))
            End Set
        End Property

        Private _posAmp As Short
        <System.ComponentModel.Bindable(True)> Public Property posAmp As Short
            Get
                Return _posAmp
            End Get
            Set(value As Short)
                _posAmp = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("posAmp"))
            End Set
        End Property

        Private _err As Short
        <System.ComponentModel.Bindable(True)> Public Property err As Short
            Get
                Return _err
            End Get
            Set(value As Short)
                _err = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("err"))
            End Set
        End Property

        Private _outP As Short
        <System.ComponentModel.Bindable(True)> Public Property outP As Short
            Get
                Return _outP
            End Get
            Set(value As Short)
                _outP = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("outP"))
            End Set
        End Property

        Private _outI As Short
        <System.ComponentModel.Bindable(True)> Public Property outI As Short
            Get
                Return _outI
            End Get
            Set(value As Short)
                _outI = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("outI"))
            End Set
        End Property

        Private _outD As Short
        <System.ComponentModel.Bindable(True)> Public Property outD As Short
            Get
                Return _outD
            End Get
            Set(value As Short)
                _outD = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("outD"))
            End Set
        End Property

        Private _outFF As Short
        <System.ComponentModel.Bindable(True)> Public Property outFF As Short
            Get
                Return _outFF
            End Get
            Set(value As Short)
                _outFF = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("outFF"))
            End Set
        End Property

        Private _task As Int32
        <System.ComponentModel.Bindable(True)> Public Property task As Int32
            Get
                Return _task
            End Get
            Set(value As Int32)
                _task = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("task"))
            End Set
        End Property

        Private _kpInv As Short
        <System.ComponentModel.Bindable(True)> Public Property kpInv As Short
            Get
                Return _kpInv
            End Get
            Set(value As Short)
                _kpInv = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("kpInv"))
            End Set
        End Property

        Private _kpInvNeg As Short
        <System.ComponentModel.Bindable(True)> Public Property kpInvNeg As Short
            Get
                Return _kpInvNeg
            End Get
            Set(value As Short)
                _kpInvNeg = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("kpInvNeg"))
            End Set
        End Property

        Private _kiInv As Short
        <System.ComponentModel.Bindable(True)> Public Property kiInv As Short
            Get
                Return _kiInv
            End Get
            Set(value As Short)
                _kiInv = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("kiInv"))
            End Set
        End Property

        Private _iMax As Short
        <System.ComponentModel.Bindable(True)> Public Property iMAx As Short
            Get
                Return _iMax
            End Get
            Set(value As Short)
                _iMax = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("iMax"))
            End Set
        End Property

        Private _iWin As Short
        <System.ComponentModel.Bindable(True)> Public Property iWin As Short
            Get
                Return _iWin
            End Get
            Set(value As Short)
                _iWin = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("iWin"))
            End Set
        End Property

        Private _iWinMax As Short
        <System.ComponentModel.Bindable(True)> Public Property iWinMax As Short
            Get
                Return _iWinMax
            End Get
            Set(value As Short)
                _iWinMax = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("iWinMax"))
            End Set
        End Property

        Private _kpD As Short
        <System.ComponentModel.Bindable(True)> Public Property kpD As Short
            Get
                Return _kpD
            End Get
            Set(value As Short)
                _kpD = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("kpD"))
            End Set
        End Property

        Private _kpDNeg As Short
        <System.ComponentModel.Bindable(True)> Public Property kpDNeg As Short
            Get
                Return _kpDNeg
            End Get
            Set(value As Short)
                _kpDNeg = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("kpDNeg"))
            End Set
        End Property

        Private _kpFF As Short
        <System.ComponentModel.Bindable(True)> Public Property kpFF As Short
            Get
                Return _kpFF
            End Get
            Set(value As Short)
                _kpFF = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("kpFF"))
            End Set
        End Property

        Private _kpFFNeg As Short
        <System.ComponentModel.Bindable(True)> Public Property kpFFNeg As Short
            Get
                Return _kpFFNeg
            End Get
            Set(value As Short)
                _kpFFNeg = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("kpFFNeg"))
            End Set
        End Property

        Private _tpsAB As Short
        <System.ComponentModel.Bindable(True)> Public Property tpsAB As Short
            Get
                Return _tpsAB
            End Get
            Set(value As Short)
                _tpsAB = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tpsAB"))
            End Set
        End Property

        Private _DCerr As Short
        <System.ComponentModel.Bindable(True)> Public Property DCerr As Short
            Get
                Return _DCerr
            End Get
            Set(value As Short)
                _DCerr = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("DCerr"))
            End Set
        End Property

        Private _pwmOfs As Short
        <System.ComponentModel.Bindable(True)> Public Property pwmOfs As Short
            Get
                Return _pwmOfs
            End Get
            Set(value As Short)
                _pwmOfs = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("pwmOfs"))
            End Set
        End Property

        Private _bitPrm As UShort
        <System.ComponentModel.Bindable(True)> Public Property bitPrm As UShort
            Get
                Return _bitPrm
            End Get
            Set(value As UShort)
                _bitPrm = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("bitPrm"))
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("bitPrm0"))
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("bitPrm1"))
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("bitPrm2"))
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("bitPrm3"))
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("bitPrm4"))
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("bitPrm5"))
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("bitPrm6"))
            End Set
        End Property

        <System.ComponentModel.Bindable(True)> Public Property bitPrm0 As Boolean
            Get
                Return (bitPrm And CUShort(&H1)) > 0
            End Get
            Set(value As Boolean)
                If value Then
                    bitPrm = bitPrm Or CUShort(&H1)
                Else
                    bitPrm = bitPrm And CUShort(&HFFFE)
                End If
                'RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("bitPrm0"))
            End Set
        End Property

        <System.ComponentModel.Bindable(True)> Public Property bitPrm1 As Boolean
            Get
                Return (bitPrm And CUShort(&H2)) > 0
            End Get
            Set(value As Boolean)
                If value Then
                    bitPrm = bitPrm Or CUShort(&H2)
                Else
                    bitPrm = bitPrm And CUShort(&HFFFD)
                End If
                'RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("bitPrm1"))
            End Set
        End Property

        <System.ComponentModel.Bindable(True)> Public Property bitPrm2 As Boolean
            Get
                Return (bitPrm And CUShort(&H4)) > 0
            End Get
            Set(value As Boolean)
                If value Then
                    bitPrm = bitPrm Or CUShort(&H4)
                Else
                    bitPrm = bitPrm And CUShort(&HFFFB)
                End If
                'RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("bitPrm2"))
            End Set
        End Property

        <System.ComponentModel.Bindable(True)> Public Property bitPrm3 As Boolean
            Get
                Return (bitPrm And CUShort(&H8)) > 0
            End Get
            Set(value As Boolean)
                If value Then
                    bitPrm = bitPrm Or CUShort(&H8)
                Else
                    bitPrm = bitPrm And CUShort(&HFFF7)
                End If
                'RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("bitPrm3"))
            End Set
        End Property

        <System.ComponentModel.Bindable(True)> Public Property bitPrm4 As Boolean
            Get
                Return (bitPrm And CUShort(&H10)) > 0
            End Get
            Set(value As Boolean)
                If value Then
                    bitPrm = bitPrm Or CUShort(&H10)
                Else
                    bitPrm = bitPrm And CUShort(&HFFEF)
                End If
                'RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("bitPrm4"))
            End Set
        End Property

        <System.ComponentModel.Bindable(True)> Public Property bitPrm5 As Boolean
            Get
                Return (bitPrm And CUShort(&H20)) > 0
            End Get
            Set(value As Boolean)
                If value Then
                    bitPrm = bitPrm Or CUShort(&H20)
                Else
                    bitPrm = bitPrm And CUShort(&HFFDF)
                End If
                'RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("bitPrm5"))
            End Set
        End Property

        <System.ComponentModel.Bindable(True)> Public Property bitPrm6 As Boolean
            Get
                Return (bitPrm And CUShort(&H40)) > 0
            End Get
            Set(value As Boolean)
                If value Then
                    bitPrm = bitPrm Or CUShort(&H40)
                Else
                    bitPrm = bitPrm And CUShort(&HFFBF)
                End If
                'RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("bitPrm5"))
            End Set
        End Property

        Private _spMin As Short
        <System.ComponentModel.Bindable(True)> Public Property spMin As Short
            Get
                Return _spMin
            End Get
            Set(value As Short)
                _spMin = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("spMin"))
            End Set
        End Property

        Private _spMax As Short
        <System.ComponentModel.Bindable(True)> Public Property spMax As Short
            Get
                Return _spMax
            End Get
            Set(value As Short)
                _spMax = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("spMax"))
            End Set
        End Property

        Private _tpsMin As Short
        <System.ComponentModel.Bindable(True)> Public Property tpsMin As Short
            Get
                Return _tpsMin
            End Get
            Set(value As Short)
                _tpsMin = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tpsMin"))
            End Set
        End Property

        Private _tpsMax As Short
        <System.ComponentModel.Bindable(True)> Public Property tpsMax As Short
            Get
                Return _tpsMax
            End Get
            Set(value As Short)
                _tpsMax = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tpsMax"))
            End Set
        End Property

        Private _sSnd As Int32
        <System.ComponentModel.Bindable(True)> Public Property sSnd As Int32
            Get
                Return _sSnd
            End Get
            Set(value As Int32)
                _sSnd = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("sSnd"))
            End Set
        End Property

        Private _pTsk As Int32
        <System.ComponentModel.Bindable(True)> Public Property pTsk As Int32
            Get
                Return _pTsk
            End Get
            Set(value As Int32)
                _pTsk = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("pTsk"))
            End Set
        End Property

        Private _tblSp0 As Short
        <System.ComponentModel.Bindable(True)> Public Property tblSp0 As Short
            Get
                Return _tblSp0
            End Get
            Set(value As Short)
                _tblSp0 = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tblSp0"))
            End Set
        End Property

        Private _tblSp1 As Short
        <System.ComponentModel.Bindable(True)> Public Property tblSp1 As Short
            Get
                Return _tblSp1
            End Get
            Set(value As Short)
                _tblSp1 = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tblSp1"))
            End Set
        End Property

        Private _tblSp2 As Short
        <System.ComponentModel.Bindable(True)> Public Property tblSp2 As Short
            Get
                Return _tblSp2
            End Get
            Set(value As Short)
                _tblSp2 = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tblSp2"))
            End Set
        End Property

        Private _tblSp3 As Short
        <System.ComponentModel.Bindable(True)> Public Property tblSp3 As Short
            Get
                Return _tblSp3
            End Get
            Set(value As Short)
                _tblSp3 = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tblSp3"))
            End Set
        End Property

        Private _tblSp4 As Short
        <System.ComponentModel.Bindable(True)> Public Property tblSp4 As Short
            Get
                Return _tblSp4
            End Get
            Set(value As Short)
                _tblSp4 = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tblSp4"))
            End Set
        End Property

        Private _tblSp5 As Short
        <System.ComponentModel.Bindable(True)> Public Property tblSp5 As Short
            Get
                Return _tblSp5
            End Get
            Set(value As Short)
                _tblSp5 = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tblSp5"))
            End Set
        End Property

        Private _tblSp6 As Short
        <System.ComponentModel.Bindable(True)> Public Property tblSp6 As Short
            Get
                Return _tblSp6
            End Get
            Set(value As Short)
                _tblSp6 = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tblSp6"))
            End Set
        End Property

        Private _tblSp7 As Short
        <System.ComponentModel.Bindable(True)> Public Property tblSp7 As Short
            Get
                Return _tblSp7
            End Get
            Set(value As Short)
                _tblSp7 = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tblSp7"))
            End Set
        End Property

        Private _tblSp8 As Short
        <System.ComponentModel.Bindable(True)> Public Property tblSp8 As Short
            Get
                Return _tblSp8
            End Get
            Set(value As Short)
                _tblSp8 = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tblSp8"))
            End Set
        End Property

        Private _tblSp9 As Short
        <System.ComponentModel.Bindable(True)> Public Property tblSp9 As Short
            Get
                Return _tblSp9
            End Get
            Set(value As Short)
                _tblSp9 = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tblSp9"))
            End Set
        End Property

        Private _tblSp10 As Short
        <System.ComponentModel.Bindable(True)> Public Property tblSp10 As Short
            Get
                Return _tblSp10
            End Get
            Set(value As Short)
                _tblSp10 = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tblSp10"))
            End Set
        End Property

        Private _tblSp11 As Short
        <System.ComponentModel.Bindable(True)> Public Property tblSp11 As Short
            Get
                Return _tblSp11
            End Get
            Set(value As Short)
                _tblSp11 = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tblSp11"))
            End Set
        End Property

        Private _tblSp12 As Short
        <System.ComponentModel.Bindable(True)> Public Property tblSp12 As Short
            Get
                Return _tblSp12
            End Get
            Set(value As Short)
                _tblSp12 = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tblSp12"))
            End Set
        End Property

        Private _tblSp13 As Short
        <System.ComponentModel.Bindable(True)> Public Property tblSp13 As Short
            Get
                Return _tblSp13
            End Get
            Set(value As Short)
                _tblSp13 = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tblSp13"))
            End Set
        End Property

        Private _tblSp14 As Short
        <System.ComponentModel.Bindable(True)> Public Property tblSp14 As Short
            Get
                Return _tblSp14
            End Get
            Set(value As Short)
                _tblSp14 = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tblSp14"))
            End Set
        End Property

        Private _tblSp15 As Short
        <System.ComponentModel.Bindable(True)> Public Property tblSp15 As Short
            Get
                Return _tblSp15
            End Get
            Set(value As Short)
                _tblSp15 = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tblSp15"))
            End Set
        End Property

        Private _tblPos0 As Short
        <System.ComponentModel.Bindable(True)> Public Property tblPos0 As Short
            Get
                Return _tblPos0
            End Get
            Set(value As Short)
                _tblPos0 = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tblPos0"))
            End Set
        End Property

        Private _tblPos1 As Short
        <System.ComponentModel.Bindable(True)> Public Property tblPos1 As Short
            Get
                Return _tblPos1
            End Get
            Set(value As Short)
                _tblPos1 = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tblPos1"))
            End Set
        End Property

        Private _tblPos2 As Short
        <System.ComponentModel.Bindable(True)> Public Property tblPos2 As Short
            Get
                Return _tblPos2
            End Get
            Set(value As Short)
                _tblPos2 = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tblPos2"))
            End Set
        End Property

        Private _tblPos3 As Short
        <System.ComponentModel.Bindable(True)> Public Property tblPos3 As Short
            Get
                Return _tblPos3
            End Get
            Set(value As Short)
                _tblPos3 = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tblPos3"))
            End Set
        End Property

        Private _tblPos4 As Short
        <System.ComponentModel.Bindable(True)> Public Property tblPos4 As Short
            Get
                Return _tblPos4
            End Get
            Set(value As Short)
                _tblPos4 = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tblPos4"))
            End Set
        End Property

        Private _tblPos5 As Short
        <System.ComponentModel.Bindable(True)> Public Property tblPos5 As Short
            Get
                Return _tblPos5
            End Get
            Set(value As Short)
                _tblPos5 = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tblPos5"))
            End Set
        End Property

        Private _tblPos6 As Short
        <System.ComponentModel.Bindable(True)> Public Property tblPos6 As Short
            Get
                Return _tblPos6
            End Get
            Set(value As Short)
                _tblPos6 = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tblPos6"))
            End Set
        End Property

        Private _tblPos7 As Short
        <System.ComponentModel.Bindable(True)> Public Property tblPos7 As Short
            Get
                Return _tblPos7
            End Get
            Set(value As Short)
                _tblPos7 = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tblPos7"))
            End Set
        End Property

        Private _tblPos8 As Short
        <System.ComponentModel.Bindable(True)> Public Property tblPos8 As Short
            Get
                Return _tblPos8
            End Get
            Set(value As Short)
                _tblPos8 = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tblPos8"))
            End Set
        End Property

        Private _tblPos9 As Short
        <System.ComponentModel.Bindable(True)> Public Property tblPos9 As Short
            Get
                Return _tblPos9
            End Get
            Set(value As Short)
                _tblPos9 = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tblPos9"))
            End Set
        End Property

        Private _tblPos10 As Short
        <System.ComponentModel.Bindable(True)> Public Property tblPos10 As Short
            Get
                Return _tblPos10
            End Get
            Set(value As Short)
                _tblPos10 = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tblPos10"))
            End Set
        End Property

        Private _tblPos11 As Short
        <System.ComponentModel.Bindable(True)> Public Property tblPos11 As Short
            Get
                Return _tblPos11
            End Get
            Set(value As Short)
                _tblPos11 = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tblPos11"))
            End Set
        End Property

        Private _tblPos12 As Short
        <System.ComponentModel.Bindable(True)> Public Property tblPos12 As Short
            Get
                Return _tblPos12
            End Get
            Set(value As Short)
                _tblPos12 = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tblPos12"))
            End Set
        End Property

        Private _tblPos13 As Short
        <System.ComponentModel.Bindable(True)> Public Property tblPos13 As Short
            Get
                Return _tblPos13
            End Get
            Set(value As Short)
                _tblPos13 = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tblPos13"))
            End Set
        End Property

        Private _tblPos14 As Short
        <System.ComponentModel.Bindable(True)> Public Property tblPos14 As Short
            Get
                Return _tblPos14
            End Get
            Set(value As Short)
                _tblPos14 = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tblPos14"))
            End Set
        End Property

        Private _tblPos15 As Short
        <System.ComponentModel.Bindable(True)> Public Property tblPos15 As Short
            Get
                Return _tblPos15
            End Get
            Set(value As Short)
                _tblPos15 = value
                RaiseEvent PropertyChanged(Me, New System.ComponentModel.PropertyChangedEventArgs("tblPos15"))
            End Set
        End Property

    End Class


End Class


