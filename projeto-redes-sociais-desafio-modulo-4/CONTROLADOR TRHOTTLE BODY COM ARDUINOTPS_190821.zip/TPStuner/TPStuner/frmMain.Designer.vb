﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.comPort = New System.IO.Ports.SerialPort(Me.components)
        Me.ToolStrip = New System.Windows.Forms.ToolStrip()
        Me.tsSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.StatusStrip = New System.Windows.Forms.StatusStrip()
        Me.sslLoop = New System.Windows.Forms.ToolStripStatusLabel()
        Me.splitMain = New System.Windows.Forms.SplitContainer()
        Me.splitView = New System.Windows.Forms.SplitContainer()
        Me.dpnlTrend = New TPStuner.DoubleBufferPanel()
        Me.dpnlInfo = New TPStuner.DoubleBufferPanel()
        Me.dpnlGauge = New TPStuner.DoubleBufferPanel()
        Me.flpValues = New System.Windows.Forms.FlowLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblPosSp = New System.Windows.Forms.Label()
        Me.lblPosSpIn = New System.Windows.Forms.Label()
        Me.lblPosSpRaw = New System.Windows.Forms.Label()
        Me.lblSp = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.lblPosTpsARaw = New System.Windows.Forms.Label()
        Me.lblPosTpsBRaw = New System.Windows.Forms.Label()
        Me.lblPosTps = New System.Windows.Forms.Label()
        Me.lblTpsA = New System.Windows.Forms.Label()
        Me.lblTpsB = New System.Windows.Forms.Label()
        Me.lblTps = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.lblPosAmp = New System.Windows.Forms.Label()
        Me.lblPosAmpRaw = New System.Windows.Forms.Label()
        Me.lblAmp = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.lblDemPwm = New System.Windows.Forms.Label()
        Me.lblErr = New System.Windows.Forms.Label()
        Me.lblDemand = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.lblOutFF = New System.Windows.Forms.Label()
        Me.lblOutI = New System.Windows.Forms.Label()
        Me.lblOutP = New System.Windows.Forms.Label()
        Me.lblOutD = New System.Windows.Forms.Label()
        Me.lblPID = New System.Windows.Forms.Label()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.lblTask = New System.Windows.Forms.Label()
        Me.lblTaskMs = New System.Windows.Forms.Label()
        Me.Timer = New System.Windows.Forms.Timer(Me.components)
        Me.tsbOpen = New System.Windows.Forms.ToolStripButton()
        Me.tsbClose = New System.Windows.Forms.ToolStripButton()
        Me.tsbSettings = New System.Windows.Forms.ToolStripButton()
        Me.ToolStrip.SuspendLayout()
        Me.StatusStrip.SuspendLayout()
        CType(Me.splitMain, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.splitMain.Panel1.SuspendLayout()
        Me.splitMain.Panel2.SuspendLayout()
        Me.splitMain.SuspendLayout()
        CType(Me.splitView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.splitView.Panel1.SuspendLayout()
        Me.splitView.Panel2.SuspendLayout()
        Me.splitView.SuspendLayout()
        Me.flpValues.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.SuspendLayout()
        '
        'comPort
        '
        Me.comPort.BaudRate = 115200
        Me.comPort.PortName = "COM3"
        '
        'ToolStrip
        '
        Me.ToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsbOpen, Me.tsbClose, Me.tsSeparator1, Me.tsbSettings})
        Me.ToolStrip.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow
        Me.ToolStrip.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip.Name = "ToolStrip"
        Me.ToolStrip.Padding = New System.Windows.Forms.Padding(0, 5, 2, 0)
        Me.ToolStrip.Size = New System.Drawing.Size(942, 43)
        Me.ToolStrip.TabIndex = 7
        Me.ToolStrip.Text = "ToolStrip"
        '
        'tsSeparator1
        '
        Me.tsSeparator1.Name = "tsSeparator1"
        Me.tsSeparator1.Size = New System.Drawing.Size(6, 38)
        '
        'StatusStrip
        '
        Me.StatusStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.sslLoop})
        Me.StatusStrip.Location = New System.Drawing.Point(0, 477)
        Me.StatusStrip.Name = "StatusStrip"
        Me.StatusStrip.Size = New System.Drawing.Size(942, 22)
        Me.StatusStrip.TabIndex = 8
        Me.StatusStrip.Text = "StatusStrip"
        '
        'sslLoop
        '
        Me.sslLoop.Name = "sslLoop"
        Me.sslLoop.Size = New System.Drawing.Size(47, 17)
        Me.sslLoop.Text = "no msg"
        '
        'splitMain
        '
        Me.splitMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.splitMain.FixedPanel = System.Windows.Forms.FixedPanel.Panel2
        Me.splitMain.Location = New System.Drawing.Point(0, 43)
        Me.splitMain.Name = "splitMain"
        Me.splitMain.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'splitMain.Panel1
        '
        Me.splitMain.Panel1.Controls.Add(Me.splitView)
        '
        'splitMain.Panel2
        '
        Me.splitMain.Panel2.Controls.Add(Me.flpValues)
        Me.splitMain.Size = New System.Drawing.Size(942, 434)
        Me.splitMain.SplitterDistance = 342
        Me.splitMain.TabIndex = 9
        '
        'splitView
        '
        Me.splitView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.splitView.FixedPanel = System.Windows.Forms.FixedPanel.Panel2
        Me.splitView.Location = New System.Drawing.Point(0, 0)
        Me.splitView.Name = "splitView"
        '
        'splitView.Panel1
        '
        Me.splitView.Panel1.Controls.Add(Me.dpnlTrend)
        '
        'splitView.Panel2
        '
        Me.splitView.Panel2.Controls.Add(Me.dpnlInfo)
        Me.splitView.Panel2.Controls.Add(Me.dpnlGauge)
        Me.splitView.Size = New System.Drawing.Size(942, 342)
        Me.splitView.SplitterDistance = 684
        Me.splitView.TabIndex = 0
        '
        'dpnlTrend
        '
        Me.dpnlTrend.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dpnlTrend.Location = New System.Drawing.Point(3, 3)
        Me.dpnlTrend.Name = "dpnlTrend"
        Me.dpnlTrend.Size = New System.Drawing.Size(678, 336)
        Me.dpnlTrend.TabIndex = 5
        '
        'dpnlInfo
        '
        Me.dpnlInfo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dpnlInfo.Location = New System.Drawing.Point(3, 261)
        Me.dpnlInfo.Name = "dpnlInfo"
        Me.dpnlInfo.Size = New System.Drawing.Size(248, 78)
        Me.dpnlInfo.TabIndex = 5
        '
        'dpnlGauge
        '
        Me.dpnlGauge.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dpnlGauge.Location = New System.Drawing.Point(3, 3)
        Me.dpnlGauge.Name = "dpnlGauge"
        Me.dpnlGauge.Size = New System.Drawing.Size(248, 252)
        Me.dpnlGauge.TabIndex = 4
        '
        'flpValues
        '
        Me.flpValues.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.flpValues.Controls.Add(Me.Panel1)
        Me.flpValues.Controls.Add(Me.Panel2)
        Me.flpValues.Controls.Add(Me.Panel3)
        Me.flpValues.Controls.Add(Me.Panel4)
        Me.flpValues.Controls.Add(Me.Panel5)
        Me.flpValues.Controls.Add(Me.Panel6)
        Me.flpValues.FlowDirection = System.Windows.Forms.FlowDirection.TopDown
        Me.flpValues.Location = New System.Drawing.Point(3, 3)
        Me.flpValues.Name = "flpValues"
        Me.flpValues.Size = New System.Drawing.Size(936, 82)
        Me.flpValues.TabIndex = 29
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.lblPosSp)
        Me.Panel1.Controls.Add(Me.lblPosSpIn)
        Me.Panel1.Controls.Add(Me.lblPosSpRaw)
        Me.Panel1.Controls.Add(Me.lblSp)
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(243, 23)
        Me.Panel1.TabIndex = 0
        '
        'lblPosSp
        '
        Me.lblPosSp.BackColor = System.Drawing.Color.Black
        Me.lblPosSp.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblPosSp.Location = New System.Drawing.Point(177, 3)
        Me.lblPosSp.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblPosSp.Name = "lblPosSp"
        Me.lblPosSp.Size = New System.Drawing.Size(57, 18)
        Me.lblPosSp.TabIndex = 16
        Me.lblPosSp.Text = "1024"
        Me.lblPosSp.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblPosSpIn
        '
        Me.lblPosSpIn.BackColor = System.Drawing.Color.Black
        Me.lblPosSpIn.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblPosSpIn.Location = New System.Drawing.Point(114, 3)
        Me.lblPosSpIn.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblPosSpIn.Name = "lblPosSpIn"
        Me.lblPosSpIn.Size = New System.Drawing.Size(57, 18)
        Me.lblPosSpIn.TabIndex = 15
        Me.lblPosSpIn.Text = "1024"
        Me.lblPosSpIn.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblPosSpRaw
        '
        Me.lblPosSpRaw.BackColor = System.Drawing.Color.Black
        Me.lblPosSpRaw.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblPosSpRaw.Location = New System.Drawing.Point(51, 3)
        Me.lblPosSpRaw.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblPosSpRaw.Name = "lblPosSpRaw"
        Me.lblPosSpRaw.Size = New System.Drawing.Size(57, 18)
        Me.lblPosSpRaw.TabIndex = 14
        Me.lblPosSpRaw.Text = "1024"
        Me.lblPosSpRaw.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblSp
        '
        Me.lblSp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSp.Location = New System.Drawing.Point(3, 3)
        Me.lblSp.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblSp.Name = "lblSp"
        Me.lblSp.Size = New System.Drawing.Size(48, 18)
        Me.lblSp.TabIndex = 6
        Me.lblSp.Text = "REF"
        Me.lblSp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.lblPosTpsARaw)
        Me.Panel2.Controls.Add(Me.lblPosTpsBRaw)
        Me.Panel2.Controls.Add(Me.lblPosTps)
        Me.Panel2.Controls.Add(Me.lblTpsA)
        Me.Panel2.Controls.Add(Me.lblTpsB)
        Me.Panel2.Controls.Add(Me.lblTps)
        Me.Panel2.Location = New System.Drawing.Point(3, 32)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(243, 44)
        Me.Panel2.TabIndex = 1
        '
        'lblPosTpsARaw
        '
        Me.lblPosTpsARaw.BackColor = System.Drawing.Color.Black
        Me.lblPosTpsARaw.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblPosTpsARaw.Location = New System.Drawing.Point(51, 3)
        Me.lblPosTpsARaw.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblPosTpsARaw.Name = "lblPosTpsARaw"
        Me.lblPosTpsARaw.Size = New System.Drawing.Size(57, 18)
        Me.lblPosTpsARaw.TabIndex = 4
        Me.lblPosTpsARaw.Text = "1024"
        Me.lblPosTpsARaw.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblPosTpsBRaw
        '
        Me.lblPosTpsBRaw.BackColor = System.Drawing.Color.Black
        Me.lblPosTpsBRaw.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblPosTpsBRaw.Location = New System.Drawing.Point(51, 24)
        Me.lblPosTpsBRaw.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblPosTpsBRaw.Name = "lblPosTpsBRaw"
        Me.lblPosTpsBRaw.Size = New System.Drawing.Size(57, 18)
        Me.lblPosTpsBRaw.TabIndex = 5
        Me.lblPosTpsBRaw.Text = "1024"
        Me.lblPosTpsBRaw.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblPosTps
        '
        Me.lblPosTps.BackColor = System.Drawing.Color.Black
        Me.lblPosTps.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblPosTps.Location = New System.Drawing.Point(177, 13)
        Me.lblPosTps.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblPosTps.Name = "lblPosTps"
        Me.lblPosTps.Size = New System.Drawing.Size(57, 18)
        Me.lblPosTps.TabIndex = 15
        Me.lblPosTps.Text = "1024"
        Me.lblPosTps.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblTpsA
        '
        Me.lblTpsA.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTpsA.Location = New System.Drawing.Point(3, 3)
        Me.lblTpsA.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblTpsA.Name = "lblTpsA"
        Me.lblTpsA.Size = New System.Drawing.Size(48, 18)
        Me.lblTpsA.TabIndex = 7
        Me.lblTpsA.Text = "TPS A"
        Me.lblTpsA.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTpsB
        '
        Me.lblTpsB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTpsB.Location = New System.Drawing.Point(3, 24)
        Me.lblTpsB.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblTpsB.Name = "lblTpsB"
        Me.lblTpsB.Size = New System.Drawing.Size(48, 18)
        Me.lblTpsB.TabIndex = 28
        Me.lblTpsB.Text = "TPS B"
        Me.lblTpsB.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblTps
        '
        Me.lblTps.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTps.Location = New System.Drawing.Point(107, 13)
        Me.lblTps.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblTps.Name = "lblTps"
        Me.lblTps.Size = New System.Drawing.Size(71, 18)
        Me.lblTps.TabIndex = 29
        Me.lblTps.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.lblPosAmp)
        Me.Panel3.Controls.Add(Me.lblPosAmpRaw)
        Me.Panel3.Controls.Add(Me.lblAmp)
        Me.Panel3.Location = New System.Drawing.Point(252, 3)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(187, 23)
        Me.Panel3.TabIndex = 2
        '
        'lblPosAmp
        '
        Me.lblPosAmp.BackColor = System.Drawing.Color.Black
        Me.lblPosAmp.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblPosAmp.Location = New System.Drawing.Point(124, 3)
        Me.lblPosAmp.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblPosAmp.Name = "lblPosAmp"
        Me.lblPosAmp.Size = New System.Drawing.Size(57, 18)
        Me.lblPosAmp.TabIndex = 16
        Me.lblPosAmp.Text = "1024"
        Me.lblPosAmp.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblPosAmpRaw
        '
        Me.lblPosAmpRaw.BackColor = System.Drawing.Color.Black
        Me.lblPosAmpRaw.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblPosAmpRaw.Location = New System.Drawing.Point(61, 3)
        Me.lblPosAmpRaw.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblPosAmpRaw.Name = "lblPosAmpRaw"
        Me.lblPosAmpRaw.Size = New System.Drawing.Size(57, 18)
        Me.lblPosAmpRaw.TabIndex = 8
        Me.lblPosAmpRaw.Text = "1024"
        Me.lblPosAmpRaw.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblAmp
        '
        Me.lblAmp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblAmp.Location = New System.Drawing.Point(3, 3)
        Me.lblAmp.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblAmp.Name = "lblAmp"
        Me.lblAmp.Size = New System.Drawing.Size(58, 18)
        Me.lblAmp.TabIndex = 9
        Me.lblAmp.Text = "Current"
        Me.lblAmp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.lblDemPwm)
        Me.Panel4.Controls.Add(Me.lblErr)
        Me.Panel4.Controls.Add(Me.lblDemand)
        Me.Panel4.Location = New System.Drawing.Point(252, 32)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(187, 23)
        Me.Panel4.TabIndex = 3
        '
        'lblDemPwm
        '
        Me.lblDemPwm.BackColor = System.Drawing.Color.Black
        Me.lblDemPwm.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblDemPwm.Location = New System.Drawing.Point(61, 3)
        Me.lblDemPwm.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblDemPwm.Name = "lblDemPwm"
        Me.lblDemPwm.Size = New System.Drawing.Size(57, 18)
        Me.lblDemPwm.TabIndex = 17
        Me.lblDemPwm.Text = "1024 pwm"
        Me.lblDemPwm.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblErr
        '
        Me.lblErr.BackColor = System.Drawing.Color.Black
        Me.lblErr.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblErr.Location = New System.Drawing.Point(124, 3)
        Me.lblErr.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblErr.Name = "lblErr"
        Me.lblErr.Size = New System.Drawing.Size(57, 18)
        Me.lblErr.TabIndex = 20
        Me.lblErr.Text = "1024"
        Me.lblErr.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblDemand
        '
        Me.lblDemand.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblDemand.Location = New System.Drawing.Point(3, 3)
        Me.lblDemand.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblDemand.Name = "lblDemand"
        Me.lblDemand.Size = New System.Drawing.Size(58, 18)
        Me.lblDemand.TabIndex = 18
        Me.lblDemand.Text = "Demand"
        Me.lblDemand.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.lblOutFF)
        Me.Panel5.Controls.Add(Me.lblOutI)
        Me.Panel5.Controls.Add(Me.lblOutP)
        Me.Panel5.Controls.Add(Me.lblOutD)
        Me.Panel5.Controls.Add(Me.lblPID)
        Me.Panel5.Location = New System.Drawing.Point(445, 3)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(187, 44)
        Me.Panel5.TabIndex = 4
        '
        'lblOutFF
        '
        Me.lblOutFF.BackColor = System.Drawing.Color.Black
        Me.lblOutFF.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblOutFF.Location = New System.Drawing.Point(132, 24)
        Me.lblOutFF.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblOutFF.Name = "lblOutFF"
        Me.lblOutFF.Size = New System.Drawing.Size(48, 18)
        Me.lblOutFF.TabIndex = 26
        Me.lblOutFF.Text = "1024"
        Me.lblOutFF.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblOutI
        '
        Me.lblOutI.BackColor = System.Drawing.Color.Black
        Me.lblOutI.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblOutI.Location = New System.Drawing.Point(132, 3)
        Me.lblOutI.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblOutI.Name = "lblOutI"
        Me.lblOutI.Size = New System.Drawing.Size(48, 18)
        Me.lblOutI.TabIndex = 24
        Me.lblOutI.Text = "1024"
        Me.lblOutI.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblOutP
        '
        Me.lblOutP.BackColor = System.Drawing.Color.Black
        Me.lblOutP.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblOutP.Location = New System.Drawing.Point(78, 3)
        Me.lblOutP.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblOutP.Name = "lblOutP"
        Me.lblOutP.Size = New System.Drawing.Size(48, 18)
        Me.lblOutP.TabIndex = 22
        Me.lblOutP.Text = "255"
        Me.lblOutP.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblOutD
        '
        Me.lblOutD.BackColor = System.Drawing.Color.Black
        Me.lblOutD.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblOutD.Location = New System.Drawing.Point(78, 24)
        Me.lblOutD.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblOutD.Name = "lblOutD"
        Me.lblOutD.Size = New System.Drawing.Size(48, 18)
        Me.lblOutD.TabIndex = 25
        Me.lblOutD.Text = "1024"
        Me.lblOutD.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblPID
        '
        Me.lblPID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblPID.Location = New System.Drawing.Point(3, 15)
        Me.lblPID.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblPID.Name = "lblPID"
        Me.lblPID.Size = New System.Drawing.Size(76, 18)
        Me.lblPID.TabIndex = 23
        Me.lblPID.Text = "PID pwm"
        Me.lblPID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.lblTask)
        Me.Panel6.Controls.Add(Me.lblTaskMs)
        Me.Panel6.Location = New System.Drawing.Point(445, 53)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(187, 23)
        Me.Panel6.TabIndex = 5
        '
        'lblTask
        '
        Me.lblTask.BackColor = System.Drawing.Color.Black
        Me.lblTask.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.lblTask.Location = New System.Drawing.Point(78, 3)
        Me.lblTask.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblTask.Name = "lblTask"
        Me.lblTask.Size = New System.Drawing.Size(48, 18)
        Me.lblTask.TabIndex = 26
        Me.lblTask.Text = "1024 us"
        Me.lblTask.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblTaskMs
        '
        Me.lblTaskMs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTaskMs.Location = New System.Drawing.Point(3, 3)
        Me.lblTaskMs.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.lblTaskMs.Name = "lblTaskMs"
        Me.lblTaskMs.Size = New System.Drawing.Size(75, 18)
        Me.lblTaskMs.TabIndex = 27
        Me.lblTaskMs.Text = "Task interval"
        Me.lblTaskMs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Timer
        '
        Me.Timer.Enabled = True
        Me.Timer.Interval = 10
        '
        'tsbOpen
        '
        Me.tsbOpen.Image = Global.TPStuner.My.Resources.Resources.hardware_16xLG
        Me.tsbOpen.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.tsbOpen.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbOpen.Name = "tsbOpen"
        Me.tsbOpen.Size = New System.Drawing.Size(40, 35)
        Me.tsbOpen.Text = "Open"
        Me.tsbOpen.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'tsbClose
        '
        Me.tsbClose.Image = Global.TPStuner.My.Resources.Resources.Disconnect_9957
        Me.tsbClose.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbClose.Name = "tsbClose"
        Me.tsbClose.Size = New System.Drawing.Size(40, 35)
        Me.tsbClose.Text = "Close"
        Me.tsbClose.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'tsbSettings
        '
        Me.tsbSettings.Image = Global.TPStuner.My.Resources.Resources.gear_16xLG
        Me.tsbSettings.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbSettings.Name = "tsbSettings"
        Me.tsbSettings.Size = New System.Drawing.Size(53, 35)
        Me.tsbSettings.Text = "Settings"
        Me.tsbSettings.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(942, 499)
        Me.Controls.Add(Me.splitMain)
        Me.Controls.Add(Me.StatusStrip)
        Me.Controls.Add(Me.ToolStrip)
        Me.DataBindings.Add(New System.Windows.Forms.Binding("Location", Global.TPStuner.My.MySettings.Default, "frmMainPos", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = Global.TPStuner.My.MySettings.Default.frmMainPos
        Me.Name = "frmMain"
        Me.Text = "TPStuner"
        Me.ToolStrip.ResumeLayout(False)
        Me.ToolStrip.PerformLayout()
        Me.StatusStrip.ResumeLayout(False)
        Me.StatusStrip.PerformLayout()
        Me.splitMain.Panel1.ResumeLayout(False)
        Me.splitMain.Panel2.ResumeLayout(False)
        CType(Me.splitMain, System.ComponentModel.ISupportInitialize).EndInit()
        Me.splitMain.ResumeLayout(False)
        Me.splitView.Panel1.ResumeLayout(False)
        Me.splitView.Panel2.ResumeLayout(False)
        CType(Me.splitView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.splitView.ResumeLayout(False)
        Me.flpValues.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.Panel6.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents comPort As System.IO.Ports.SerialPort
    Friend WithEvents ToolStrip As System.Windows.Forms.ToolStrip
    Friend WithEvents tsbOpen As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbClose As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents tsbSettings As System.Windows.Forms.ToolStripButton
    Friend WithEvents StatusStrip As System.Windows.Forms.StatusStrip
    Friend WithEvents splitMain As System.Windows.Forms.SplitContainer
    Friend WithEvents splitView As System.Windows.Forms.SplitContainer
    Friend WithEvents dpnlTrend As TPStuner.DoubleBufferPanel
    Friend WithEvents dpnlGauge As TPStuner.DoubleBufferPanel
    Friend WithEvents lblPosTpsARaw As System.Windows.Forms.Label
    Friend WithEvents Timer As System.Windows.Forms.Timer
    Friend WithEvents lblPosTpsBRaw As System.Windows.Forms.Label
    Friend WithEvents lblAmp As System.Windows.Forms.Label
    Friend WithEvents lblPosAmpRaw As System.Windows.Forms.Label
    Friend WithEvents lblTpsA As System.Windows.Forms.Label
    Friend WithEvents lblSp As System.Windows.Forms.Label
    Friend WithEvents lblPosAmp As System.Windows.Forms.Label
    Friend WithEvents lblPosTps As System.Windows.Forms.Label
    Friend WithEvents lblTaskMs As System.Windows.Forms.Label
    Friend WithEvents lblTask As System.Windows.Forms.Label
    Friend WithEvents lblOutD As System.Windows.Forms.Label
    Friend WithEvents lblOutI As System.Windows.Forms.Label
    Friend WithEvents lblPID As System.Windows.Forms.Label
    Friend WithEvents lblOutP As System.Windows.Forms.Label
    Friend WithEvents lblErr As System.Windows.Forms.Label
    Friend WithEvents lblDemand As System.Windows.Forms.Label
    Friend WithEvents lblDemPwm As System.Windows.Forms.Label
    Friend WithEvents lblTpsB As System.Windows.Forms.Label
    Friend WithEvents flpValues As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lblPosSp As System.Windows.Forms.Label
    Friend WithEvents lblPosSpIn As System.Windows.Forms.Label
    Friend WithEvents lblPosSpRaw As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents sslLoop As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblOutFF As System.Windows.Forms.Label
    Friend WithEvents lblTps As System.Windows.Forms.Label
    Friend WithEvents dpnlInfo As TPStuner.DoubleBufferPanel



End Class
